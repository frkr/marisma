package marisma.framework;

import java.io.File;

import marisma.webdav.ResourceFactory;

import com.bradmcevoy.http.CollectionResource;
import com.bradmcevoy.http.Resource;

public class ResourceFactoryFramework extends marisma.webdav.ResourceFactory {

	@Override
	public String getREALM() {
		return FrontController.REALM;
	}

	@Override
	public String getROOT() {
		return FrontController.getROOT();
	}

	@Override
	public String getURL() {
		return FrontController.URL;
	}

	@Override
	public Resource newFileResource(ResourceFactory fac, File file) {
		return new FileResource(fac, file);
	}

	@Override
	public CollectionResource newFolderResource(ResourceFactory fac, File file) {
		return new FolderResource(fac, file);
	}

}

package marisma.framework;

import java.util.Properties;

public interface SQL {
	public void call();
	public void reconfigure(Properties prop);
}

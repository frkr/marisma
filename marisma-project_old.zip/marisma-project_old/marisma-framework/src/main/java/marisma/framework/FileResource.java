package marisma.framework;

import java.io.File;

import marisma.webdav.ResourceFactory;

class FileResource extends marisma.webdav.FileResource {

	protected FileResource(ResourceFactory fac, File file) {
		super(fac, file);
	}

	@Override
	public void delete() {
		if (!this.file.getName().equals("config" + FrontController.EXT)) {
			super.delete();
		}
	}

}

package marisma.framework;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import marisma.webdav.ResourceFactory;

import com.bradmcevoy.http.Resource;

public class FolderResource extends marisma.webdav.FolderResource {

	protected FolderResource(ResourceFactory fac, File file) {
		super(fac, file);
	}

	@Override
	public Resource createNew(String name, InputStream in, Long length, String contentType) throws IOException {
		if (name.equals("config" + FrontController.EXT) && this.file.toString().equals(this.fac.getROOT())) {
			Resource rt = super.createNew(name, in, length, contentType);
			FrontController.reconfigure(new File(this.file,name)); // TODO Isso vai dar um trabalho.... O bug consiste em trocar a extencao do arquivo
			return rt;
		} else
			return super.createNew(name, in, length, contentType);
	}

}
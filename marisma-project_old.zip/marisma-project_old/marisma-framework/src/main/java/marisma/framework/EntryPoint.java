package marisma.framework;

import com.bradmcevoy.http.MiltonServlet;

/**
 * Ponto de entrada para utilizar o WebDAV do framework
 * Veja no web.xml que pode-se apenas configurar a fabrica de recursos.
 */
public class EntryPoint extends MiltonServlet {

}

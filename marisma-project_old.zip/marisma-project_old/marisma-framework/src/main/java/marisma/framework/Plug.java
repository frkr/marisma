package marisma.framework;

import java.io.ByteArrayOutputStream;

import org.jdom.Document;

public class Plug {
	private static final ThreadLocal<Plug> plug = new ThreadLocal<Plug>();

	public enum Output { PLAIN, XSLT }

	private String plugName=null;
	private Output output=Output.PLAIN;
	private Document contentJdom=null;
	private ByteArrayOutputStream content=null;
	private Boolean savexml=false;

	public static Plug setPlug(Plug plug) {
		Plug.plug.set(plug);
		return Plug.plug.get();
	}
	public static Plug getPlug() {
		return Plug.plug.get();
	}

	public Plug(String plugName){
		this.plugName=plugName;
	}
	public Plug(String plugName, Output output) {
		this(plugName);
		this.output = output;
	}

	public String getPlugName() {
		return this.plugName;
	}
	public Plug setPlugName(String plugName) {
		this.plugName = plugName;
		return this;
	}
	public ByteArrayOutputStream getContent() {
		return this.content;
	}
	public Plug setContent(ByteArrayOutputStream content) {
		this.content = content;
		return this;
	}
	public Document getContentJdom() {
		return this.contentJdom;
	}
	public Plug setContentJdom(Document contentJdom) {
		this.contentJdom = contentJdom;
		return this;
	}
	public Output getOutput() {
		return this.output;
	}
	public Plug setOutput(Output output) {
		this.output = output;
		return this;
	}
	public boolean isSaveXML() {
		return this.savexml;
	}
	public Plug saveXML(boolean savexml) {
		this.savexml = savexml;
		return this;
	}

}

package marisma.framework;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.User;
import marisma.Wrapper;
import marisma.XMLData;
import marisma.filter.RequestTrap;
import marisma.filter.ResponseTrap;
import marisma.output.OutputXSLT;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.transform.XSLTransformer;

/**
 * Ponto de entrada do Framework e consequentimente todo o sistema.
 * Tudo ir� passar por aqui
 * Veja o web.xml para ver como configura.
 */
public class FrontController implements Filter {
	private static Logger log = Logger.getLogger(FrontController.class.getName());

	private static String ROOT=null;

	public volatile static String EXT = ".marisma";
	public volatile static String URL="/framework";
	public volatile static String REALM="Marisma Framework Realm";
	public volatile static boolean CACHE=false;
	public volatile static String DONOT="";
	public final static Set<String> DONOTH = new HashSet<String>();
	public volatile static SQL SQL = null;

	public static String getROOT() {
		return FrontController.ROOT;
	}

	public void init(FilterConfig c) throws ServletException {
		String realm = c.getInitParameter("marisma.entrypoint.realm");
		if (realm!=null) {
			FrontController.REALM = realm;
		}
		FrontController.log.info("marisma.entrypoint.realm = " + FrontController.REALM);

		String path = c.getInitParameter("marisma.entrypoint.url");
		if (path!=null) {
			FrontController.URL = path;
		}
		FrontController.log.info("marisma.entrypoint.url = " + FrontController.URL);

		String ext = c.getInitParameter("marisma.framework.ext");
		if (ext!=null) {
			FrontController.EXT = ext;
		}
		FrontController.log.info("marisma.framework.ext = " + FrontController.EXT);

		FrontController.ROOT=c.getServletContext().getRealPath("/");
		FrontController.log.info("root: "+FrontController.getROOT());

		String donot = c.getInitParameter("marisma.framework.donot");
		if (donot!=null) {
			FrontController.DONOT = donot;
			FrontController.reconfigureDonot(donot);
		}
		FrontController.log.info("marisma.framework.donot = " + FrontController.DONOT);

		String sql = c.getInitParameter("marisma.framework.sql");
		if (sql!=null) {
			try {
				FrontController.SQL = (SQL) Thread.currentThread().getContextClassLoader().loadClass(sql).newInstance();
			} catch (Exception e) {
				e.printStackTrace();
				FrontController.log.severe(e.getMessage());
			}
		}
		FrontController.log.info("marisma.framework.sql = " + ((FrontController.SQL!=null) ? FrontController.SQL.getClass().getName() : ""));

		File marisma = new File(FrontController.getROOT(),"config"+FrontController.EXT);
		if (marisma.exists()) {
			FrontController.reconfigure(marisma);
		} else {
			try {
				Properties prop = new Properties();

				prop.setProperty("EXT",FrontController.EXT);
				prop.setProperty("URL",FrontController.URL);
				prop.setProperty("REALM",FrontController.REALM);
				prop.setProperty("ROOT",FrontController.getROOT());
				prop.setProperty("CACHE",Boolean.toString(FrontController.CACHE));
				prop.setProperty("USERIMPL",Wrapper.USERIMPL.getClass().getName());
				prop.setProperty("DONOT",FrontController.DONOT);
				prop.setProperty("SQL",((FrontController.SQL!=null) ? FrontController.SQL.getClass().getName() : ""));

				FileOutputStream file = new FileOutputStream(marisma);
				prop.store(file,"FrontController Config");
				file.flush();
				file.close();
			} catch (Exception e) {
				e.printStackTrace();
				FrontController.log.severe(e.getMessage());
			}
		}

	}

	private static void reconfigureDonot(String donot) {
		if (donot!=null && donot.length()>0) {
			FrontController.DONOTH.clear();
			StringTokenizer st = new StringTokenizer(donot, ",");
			while (st.hasMoreElements()) {
				String tk = st.nextToken();
				FrontController.DONOTH.add(tk);
				FrontController.log.info("donot: " + tk); // TODO retirar esta linha depois de testa-la
			}
		}
	}

	protected static void reconfigure(File marisma) {
		try {
			Properties prop = new Properties();

			FileInputStream file = new FileInputStream(marisma);
			prop.load(file);

			if (prop.getProperty("EXT") != null && !prop.getProperty("EXT").equals(FrontController.EXT)) {
				FrontController.EXT = prop.getProperty("EXT");
				FrontController.log.warning("FrontController.EXT = " + FrontController.EXT);
			}
			if (prop.getProperty("URL") != null && !prop.getProperty("URL").equals(FrontController.URL)) {
				//URL = prop.getProperty("URL");
				FrontController.log.warning("FrontController.URL (notchanged) " + prop.getProperty("URL"));
			}
			if (prop.getProperty("REALM") != null && !prop.getProperty("REALM").equals(FrontController.REALM)) {
				FrontController.REALM = prop.getProperty("REALM");
				FrontController.log.warning("FrontController.REALM = " + FrontController.REALM);
			}
			if (prop.getProperty("ROOT") != null && !prop.getProperty("ROOT").equals(FrontController.getROOT())) {
				//FrontController.ROOT = prop.getProperty("ROOT");
				FrontController.log.warning("FrontController.ROOT (notchanged) " + FrontController.getROOT());
			}
			if (prop.getProperty("CACHE") != null && !prop.getProperty("CACHE").equals(Boolean.toString(FrontController.CACHE))) {
				FrontController.CACHE = new Boolean( prop.getProperty("CACHE") );
				FrontController.log.warning("FrontController.CACHE = " + Boolean.toString(FrontController.CACHE));
			}
			if (prop.getProperty("USERIMPL") != null && !prop.getProperty("USERIMPL").equals(Wrapper.USERIMPL.getClass().getName())) {
				try {
					Wrapper.USERIMPL = (User) Thread.currentThread().getContextClassLoader().loadClass(prop.getProperty("USERIMPL")).newInstance();
				} catch (Exception e) {
					FrontController.log.severe("Class not found: " + prop.getProperty("USERIMPL"));
				}
			}
			FrontController.log.warning("Wrapper.USERIMPL = " + Wrapper.USERIMPL.getClass().getName());

			if (prop.getProperty("DONOT") != null && !prop.getProperty("DONOT").equals(FrontController.DONOT)) {
				FrontController.DONOT = prop.getProperty("DONOT");
				FrontController.reconfigureDonot(prop.getProperty("DONOT"));
				FrontController.log.warning("FrontController.DONOT = " + FrontController.DONOT);
			}

			if (prop.getProperty("SQL") != null && !prop.getProperty("SQL").equals(((FrontController.SQL!=null) ? FrontController.SQL.getClass().getName() : ""))) {
				try {
					FrontController.SQL = (SQL) Thread.currentThread().getContextClassLoader().loadClass(prop.getProperty("SQL")).newInstance();
				} catch (Exception e) {
					FrontController.log.severe("Class not found: " + prop.getProperty("USERIMPL"));
				}
			}
			FrontController.log.info("FrontController.SQL = " + ((FrontController.SQL!=null) ? FrontController.SQL.getClass().getName() : "") );

		} catch (Exception e) {
			e.printStackTrace();
			FrontController.log.severe(e.getMessage());
		}
	}

	public void doFilter(ServletRequest r, ServletResponse p, FilterChain f) throws IOException, ServletException {
		// Isso vai ser transformar em um linux... t� ate vendo.

		RequestTrap rtrap = RequestTrap.setTrapThread((HttpServletRequest) r);
		ResponseTrap ptrap = ResponseTrap.setTrapThread((HttpServletResponse) p);

		String rpath = "";
		try {
			rpath = new URI(rtrap.getContextPath()).relativize(new URI(rtrap.getServletPath())).resolve(new URI(".")).toString();
		} catch (Exception e) {
		}

		if (!FrontController.DONOTH.contains(rpath)) {
			//TODO Se for arquivos criados pelo marisma deve retornar "FORBIDDEN"
			if (rtrap.getServletPath().endsWith(FrontController.EXT)) {
				ptrap.sendError(HttpServletResponse.SC_FORBIDDEN);
				ptrap.flush();
				// TODO Fazer com que o usu�rio do WebDAV possa criar seus pr�prios arquivos.marisma
				// if (rtrap.getServletPath().endsWith("config" + FrontController.EXT)) {
			} else if (FrontController.SQL!=null && rtrap.getServletPath().endsWith(".sql")) {
				f.doFilter(rtrap, ptrap);
				FrontController.SQL.call();
			} else {

				Plug.setPlug(null);
				f.doFilter(rtrap, ptrap);
				Plug g=Plug.getPlug();

				if (g!=null) {
					File marisma = new File(FrontController.getROOT(),g.getPlugName()+FrontController.EXT);
					boolean novo = false;
					try {
						novo = marisma.createNewFile();
					} catch (Exception e) {
						e.printStackTrace();
						FrontController.log.severe(e.getMessage());
					}
					if (novo) {
						Properties prop = new Properties();

						prop.setProperty("plugName",g.getPlugName());
						prop.setProperty("output",g.getOutput().toString());

						FileOutputStream file = new FileOutputStream(marisma);
						prop.store(file,"ReadOnly");
						file.flush();
						file.close();
					} else {
						// TODO Se o arquivo .marisma j� existe. O que fazer?
					}
					if (g.getOutput().equals(Plug.Output.XSLT)) {
						this.XSLTOutput(p, ptrap, g);
					} else {
						this.PlainOutput(p, ptrap, g);
					}
				} else {
					ptrap.flush();
				}
			}

		} else {
			f.doFilter(r, p);
		}

	}

	private void PlainOutput(ServletResponse p, ResponseTrap ptrap, Plug g) throws IOException {
		byte[] b;
		if (g.getContentJdom()!=null) {
			String t = new XMLData( g.getContentJdom() ).getXML();
			p.getOutputStream().print(t);
			b = t.getBytes();
		} else if ( g.getContent() !=null ) {
			p.getOutputStream().print(g.getContent().toString());
			b = g.getContent().toByteArray();
		} else {
			ptrap.flush();
			b = ptrap.getTrap().toByteArray();
		}
		this.saveOutput(FrontController.EXT, b);
	}

	private void XSLTOutput(ServletResponse p, ResponseTrap ptrap, Plug g) throws IOException, ServletException {
		File xsl = new File(FrontController.getROOT(),g.getPlugName()+".xsl");
		if (xsl.exists()) {

			Document doc = null;
			if (g.getContentJdom() != null) {
				doc = g.getContentJdom();
			} else if (g.getContent() !=null ) {
				try {
					doc = XMLData.openXML( new ByteArrayInputStream( g.getContent().toByteArray() ) );
				} catch (JDOMException e) {
					e.printStackTrace();
					throw new ServletException(e.getMessage(), e);
				}
			} else {
				try {
					doc = XMLData.openXML( new ByteArrayInputStream( ptrap.getTrap().toByteArray() ) );
				} catch (JDOMException e) {
					e.printStackTrace();
					throw new ServletException(e.getMessage(), e);
				}
			}
			if (g.isSaveXML()) {
				this.saveOutput(".xml", new XMLData(doc).getXML().getBytes());
			}
			try {
				// TODO Implementar o CACHE de XSLT. Guardar variavel 'xslt' em uma lista rapida.
				XSLTransformer xlst = new XSLTransformer(xsl);
				p.getOutputStream().print(
						OutputXSLT.transform(xlst, doc).getXML()
				);
			} catch (JDOMException e) {
				e.printStackTrace();
				throw new ServletException(e.getMessage(), e);
			}

		} else {
			FrontController.log.warning("Not found: " + xsl);
			this.PlainOutput(p, ptrap, g);
		}

	}

	private void saveOutput(String ext, byte[] bs) {
		File output = new File(FrontController.getROOT(),Plug.getPlug().getPlugName()+ext);
		try {
			FileOutputStream fout = new FileOutputStream(output);
			fout.write(bs);
			fout.flush();
			fout.close();
		} catch (Exception e) {
			e.printStackTrace();
			FrontController.log.severe(e.getMessage());
		}
	}

	public void destroy() {
	}

}

package marisma.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;

class ServletOutputTrap extends ServletOutputStream {

	private ByteArrayOutputStream out;

	public ServletOutputTrap(ByteArrayOutputStream out) {
		this.out=out;
	}

	@Override
	public void write(int b) throws IOException {
		this.out.write(b);
	}

}

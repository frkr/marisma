package marisma.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class RequestTrap extends HttpServletRequestWrapper {
	private static final ThreadLocal<RequestTrap> trap = new ThreadLocal<RequestTrap>();

	private RequestTrap(HttpServletRequest request) {
		super(request);
	}

	public static RequestTrap getTrapThread() {
		return RequestTrap.trap.get();
	}
	// TODO Documentar no java doc que isto � arriscado
	public static RequestTrap setTrapThread(HttpServletRequest request) {
		RequestTrap.trap.set(new RequestTrap(request));
		return RequestTrap.trap.get();
	}

	@Override
	public String toString() {
		return this.getRequest().toString();
	}

}

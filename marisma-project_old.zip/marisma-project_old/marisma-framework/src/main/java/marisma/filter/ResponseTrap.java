package marisma.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class ResponseTrap extends HttpServletResponseWrapper {
	private static final ThreadLocal<ResponseTrap> trap = new ThreadLocal<ResponseTrap>();

	private ByteArrayOutputStream out=new ByteArrayOutputStream();
	private ServletOutputTrap servletout=new ServletOutputTrap(this.out);
	private PrintWriter writer=new PrintWriter(this.servletout);

	private ResponseTrap(HttpServletResponse response) {
		super(response);
	}

	public static ResponseTrap getTrapThread() {
		return ResponseTrap.trap.get();
	}
	// TODO Documentar no java doc que isto � arriscado
	public static ResponseTrap setTrapThread(HttpServletResponse response) {
		ResponseTrap.trap.set(new ResponseTrap(response));
		return ResponseTrap.trap.get();
	}

	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		return this.servletout;
	}
	public ServletOutputStream getOutputStreamReal() throws IOException {
		return super.getOutputStream();
	}

	@Override
	public PrintWriter getWriter() throws IOException {
		return this.writer;
	}
	public PrintWriter getWriterReal() throws IOException {
		return super.getWriter();
	}


	public ByteArrayOutputStream getTrap() {
		this.writer.flush();
		return this.out;
	}

	public void flush() throws IOException {
		super.getOutputStream().print(this.getTrap().toString());
	}

	@Override
	public String toString() {
		return this.getResponse().toString();
	}

}
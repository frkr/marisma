package marisma.webdav;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.bradmcevoy.common.ContentTypeUtils;
import com.bradmcevoy.http.Auth;
import com.bradmcevoy.http.FileItem;
import com.bradmcevoy.http.PropPatchableResource;
import com.bradmcevoy.http.Range;
import com.bradmcevoy.http.exceptions.BadRequestException;
import com.bradmcevoy.http.exceptions.NotAuthorizedException;
import com.bradmcevoy.io.StreamUtils;

/**
 * Esta classe ir� representar os arquivos no WebDAV que pode ser facilmente sobregravada usando "extends"
 * Veja em como {@link ResourceFactoryWebDAV} configurar.
 */
public class FileResource extends Resource implements com.bradmcevoy.http.FileResource, PropPatchableResource { // proppatch = Para o windows

	protected FileResource(ResourceFactory fac, File file) {
		super(fac,file);
	}

	@Override
	protected void doCopy( File dest ) {
		try {
			FileUtils.copyFile( this.file, dest );
		} catch( IOException ex ) {
			throw new SecurityException( "Failed doing copy to: " + dest.getAbsolutePath(), ex );
		}
	}

	@Override
	public Long getContentLength() {
		return this.file.length();
	}

	@Override
	public Long getMaxAgeSeconds(Auth arg0) {
		return null;
	}

	@Override
	public void sendContent(OutputStream out, Range range,
			Map<String, String> map, String str) throws IOException,
			NotAuthorizedException, BadRequestException {
		StreamUtils.readTo(this.file, out, true);
	}

	@Override
	public String processForm(Map<String, String> arg0,
			Map<String, FileItem> arg1) throws BadRequestException,
			NotAuthorizedException {
		// TODO nao fiz e acho que n�o precisa fazer
		throw new SecurityException("not implemented");
	}

	@Override
	public String getContentType( String preferredList ) {
		String mime = ContentTypeUtils.findContentTypes( this.file );
		return ContentTypeUtils.findAcceptableContentType( mime, preferredList );
	}

	@Override
	public void setProperties(
			com.bradmcevoy.http.webdav.PropPatchHandler.Fields fields) {
		// O Windows precisa disto
	}

}

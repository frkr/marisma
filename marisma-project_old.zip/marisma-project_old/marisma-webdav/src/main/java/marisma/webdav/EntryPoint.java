package marisma.webdav;

import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import com.bradmcevoy.http.MiltonServlet;

/**
 * Ponto de entrado do WebDAV
 * Veja o web.xml para saber como configurar
 */
public class EntryPoint extends MiltonServlet {
	private static Logger log = Logger.getLogger(EntryPoint.class.getName());

	/**
	 * Pasta root do projeto WEB
	 */
	public static String ROOT=null;
	/**
	 * Identifica��o para o browser. Somente para saber onde � o root
	 */
	public static String URL="/webdav";
	/**
	 * Para autentica��o.
	 */
	public static String REALM="Marisma WebDAV Realm";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		String realm = config.getInitParameter("marisma.entrypoint.realm");
		if (realm!=null) {
			EntryPoint.REALM = realm;
		}
		EntryPoint.log.info("marisma.entrypoint.realm = " + EntryPoint.REALM);

		String path = config.getInitParameter("marisma.entrypoint.url");
		if (path!=null) {
			EntryPoint.URL = path;
		}
		EntryPoint.log.info("marisma.entrypoint.url = " + EntryPoint.URL);

		String root = config.getInitParameter("marisma.entrypoint.root");
		if (root!=null) {
			EntryPoint.ROOT=root;
		} else {
			EntryPoint.ROOT=config.getServletContext().getRealPath("/");
		}
		EntryPoint.log.info("root: "+EntryPoint.ROOT);
	}

}

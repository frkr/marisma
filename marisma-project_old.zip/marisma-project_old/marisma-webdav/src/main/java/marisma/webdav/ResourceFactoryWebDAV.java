package marisma.webdav;

import java.io.File;

import com.bradmcevoy.http.CollectionResource;
import com.bradmcevoy.http.Resource;

/**
 * Implementa��o do webdav: Este � o ponto de entrada para o Milton
 */
public class ResourceFactoryWebDAV extends ResourceFactory {

	@Override
	public String getREALM() {
		return EntryPoint.REALM;
	}

	@Override
	public String getROOT() {
		return EntryPoint.ROOT;
	}

	@Override
	public String getURL() {
		return EntryPoint.URL;
	}

	@Override
	public Resource newFileResource(ResourceFactory fac, File file) {
		return new FileResource(fac, file);
	}

	@Override
	public CollectionResource newFolderResource(ResourceFactory fac, File file) {
		return new FolderResource(fac, file);
	}

}

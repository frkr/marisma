package marisma.webdav;

import java.io.File;

import javax.servlet.ServletRequest;

import marisma.User;
import marisma.Wrapper;

import com.bradmcevoy.http.Auth;
import com.bradmcevoy.http.CollectionResource;
import com.bradmcevoy.http.DigestResource;
import com.bradmcevoy.http.HttpManager;
import com.bradmcevoy.http.Request;
import com.bradmcevoy.http.Resource;
import com.bradmcevoy.http.Request.Method;
import com.bradmcevoy.http.http11.auth.DigestGenerator;
import com.bradmcevoy.http.http11.auth.DigestResponse;

/**
 * Implementa��o do webdav. Reutiliz�vel.
 * {@link ResourceFactoryWebDAV}
 */
public abstract class ResourceFactory implements com.bradmcevoy.http.ResourceFactory {

	/**
	 * Autentica��o Digest. Uma simples implementa��o.
	 * {@link DigestResource}
	 * @param di Parametro do Milton
	 * @return "ok" ou null;
	 */
	public Object authenticate(DigestResponse di) {
		User user = Wrapper.USERIMPL.newLogin(di.getUser());
		if (user!=null) {
			String pass = new DigestGenerator().generateDigest(di, user.getPass());
			if (di.getResponseDigest().equals(pass))
				return "ok";
		}
		return null;
	}

	/**
	 * Autentica��o Basica. Uma simples implementa��o.
	 * {@link DigestResource}
	 * @param user usu�rio
	 * @param password senha
	 * @return "ok" ou null
	 */
	public Object authenticate(String user, String password) {
		User usr = Wrapper.USERIMPL.newLogin(user,password);
		if (usr!=null)
			return "ok";
		return null;
	}

	/**
	 * Depois de autenticado o browser deve passar mais vezez por aqui. Eu simplesmente n�o sei, talvez usando este metodo podemos fazer um cache de senha...
	 * {@link DigestResource}
	 * @param request contem tipos do Request parecido com o {@link ServletRequest}
	 * @param method contem o metodo do HTTP. Eu acho meio inutil pq � sempre o mesmo m�todo.
	 * @param auth Nulo se vazio.
	 * @return se o usu�rio j� passou pela autentica��o
	 */
	public boolean authorise(Request request, Method method, Auth auth) {
		if (auth!=null) {
			User usr = Wrapper.USERIMPL.newLogin(auth.getUser(), auth.getPassword());
			if (usr!=null)
				return true;
		}
		return false;
	}

	/**
	 * Informa ao WebDAV qual o path que voc� configurou para melhor resolver os arquivos internos.
	 * {@link EntryPoint}
	 * {@link ResourceFactoryWebDAV}
	 * @return Exemplo: "/webdav"
	 */
	public abstract String getURL();
	/**
	 * Configura o path do WebDAV. Pode ser qualquer um mesmo, mas por padr�o ser� configurado o Root do aplicativo que pode ser ruim para a sua aplica��o mas � o mais comum.
	 * {@link EntryPoint}
	 * {@link ResourceFactoryWebDAV}
	 * @return O Path absoluto
	 */
	public abstract String getROOT();
	/**
	 * Talvez seja de grande importancia configurar isto para os chaveiros e outros aplicativos clientes possam guardar e salvar as senhas.
	 * {@link EntryPoint}
	 * {@link ResourceFactoryWebDAV}
	 * @return Nome do Dominio exemplo: Marisma WebDAV Realm
	 */
	public abstract String getREALM();

	public Resource getResource(String host, String url) {
		if (url.indexOf("..") != -1)
			throw new SecurityException("URI .."); // Nunca vai entrar aqui... amenos q tenha no meio do arquivo ou seja um exploit
		url = url.substring(url.indexOf(this.getURL())+this.getURL().length());
		File file = new File(this.getROOT(), url);

		// [Problema do Dreamweaver]
		if (HttpManager.request().getMethod().equals(Method.MKCOL)) {
			if (HttpManager.request().getAbsoluteUrl().indexOf("untitled") != -1)
				return null;
			else if (HttpManager.request().getAbsoluteUrl().indexOf("CRXDQWHFA") != -1) {
				url = HttpManager.request().getAbsoluteUrl();
				url = url.substring(url.indexOf(this.getURL())+this.getURL().length());
				url = url.substring(0,url.lastIndexOf("/"));
				File f = new File(this.getROOT(), url);
				f.mkdir();
			}
		}
		// [/Problema do Dreamweaver]
		return this.getResource(file);
	}

	/**
	 * Para ser reutilizavel � preciso substituir este m�todo
	 * {@link ResourceFactoryWebDAV}
	 * @param fac Esta instancia
	 * @param file Arquivo em quest�o
	 * @return uma nova instancia
	 */
	public abstract com.bradmcevoy.http.Resource newFileResource(ResourceFactory fac, File file);
	/**
	 * Para ser reutilizavel � preciso substituir este m�todo
	 * {@link ResourceFactoryWebDAV}
	 * @param fac Esta instancia
	 * @param file Arquivo em quest�o
	 * @return uma nova instancia
	 */
	public abstract CollectionResource newFolderResource(ResourceFactory fac, File file);

	protected com.bradmcevoy.http.Resource getResource(File file) {
		if (!file.exists())
			return null;
		if (!file.isDirectory())
			return this.newFileResource(this, file);
		else
			return this.newFolderResource(this, file);
	}

}

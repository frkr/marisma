package marisma.webdav;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import com.bradmcevoy.http.Auth;
import com.bradmcevoy.http.CollectionResource;
import com.bradmcevoy.http.Range;
import com.bradmcevoy.http.exceptions.BadRequestException;
import com.bradmcevoy.http.exceptions.ConflictException;
import com.bradmcevoy.http.exceptions.NotAuthorizedException;

/**
 * Esta classe ir� representar os diret�rios no WebDAV que pode ser facilmente sobregravada usando "extends"
 * Veja em como {@link ResourceFactoryWebDAV} configurar.
 */
public class FolderResource extends Resource implements com.bradmcevoy.http.FolderResource {

	protected FolderResource(ResourceFactory fac, File file) {
		super(fac,file);
	}

	@Override
	public CollectionResource createCollection(String path)
	throws NotAuthorizedException, ConflictException {
		File f = new File(this.file,path);
		f.mkdirs();
		return this.fac.newFolderResource(this.fac, f);
	}

	@Override
	public com.bradmcevoy.http.Resource child(String child) {
		//		return null; // Isso era um teste do problema de diretorio do Dreamweaver
		return this.fac.getResource(new File(this.file,child));
	}

	@Override
	public List<? extends com.bradmcevoy.http.Resource> getChildren() {
		List<com.bradmcevoy.http.Resource> list = new ArrayList<com.bradmcevoy.http.Resource>();
		for (File file: this.file.listFiles()) {
			list.add(this.fac.getResource(file));
		}
		return list;
	}

	@Override
	protected void doCopy( File dest ) {
		try {
			FileUtils.copyDirectory( this.file, dest );
		} catch( IOException ex ) {
			throw new SecurityException( "Failed to copy to:" + dest.getAbsolutePath(), ex );
		}
	}

	@Override
	public Long getContentLength() {
		return null;
	}

	@Override
	public Long getMaxAgeSeconds(Auth arg0) {
		return null;
	}

	@Override
	public void sendContent(OutputStream out, Range r,
			Map<String, String> args, String accept) throws IOException,
			NotAuthorizedException, BadRequestException {
		OutputStreamWriter w = new OutputStreamWriter(out);
		w.append("<html><body><h1>"+this.fac.getREALM()+"</h1><br><br>");
		for (com.bradmcevoy.http.Resource res: this.getChildren()) {
			w.append("<a href='"+res.getName()+((res instanceof CollectionResource) ? "/" : "")+"'>" + res.getName() + "</a><br>");
		}
		w.append("</body></html>");
		w.flush();
	}

	public com.bradmcevoy.http.Resource createNew( String name, InputStream in, Long length, String contentType ) throws IOException {
		File dest = new File( this.file, name );
		FileOutputStream out = null;
		try {
			out = new FileOutputStream( dest );
			IOUtils.copy( in, out );
		} finally {
			IOUtils.closeQuietly( out );
		}
		return this.fac.getResource(dest);
	}

	@Override
	public String getContentType(String arg0) {
		return "text/html";
	}

}

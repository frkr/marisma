package marisma.webdav;

import java.io.File;
import java.util.Date;

import com.bradmcevoy.http.Auth;
import com.bradmcevoy.http.CollectionResource;
import com.bradmcevoy.http.CopyableResource;
import com.bradmcevoy.http.DeletableResource;
import com.bradmcevoy.http.DigestResource;
import com.bradmcevoy.http.MoveableResource;
import com.bradmcevoy.http.PropFindableResource;
import com.bradmcevoy.http.Request;
import com.bradmcevoy.http.Request.Method;
import com.bradmcevoy.http.http11.auth.DigestResponse;

/**
 * Esta � a classe base dos arquivos e diret�rios.
 * Veja em como {@link ResourceFactoryWebDAV} configurar.
 */
public abstract class Resource implements DigestResource, PropFindableResource, CopyableResource, MoveableResource, DeletableResource {

	protected File file;
	protected String url;
	protected ResourceFactory fac;

	protected Resource(ResourceFactory fac, File file) {
		this.fac=fac;
		this.file=file;
		try {
			this.url=file.getAbsolutePath().substring(fac.getROOT().length()+1);
		} catch (Exception e) {
		}
	}

	@Override
	public Object authenticate(String user, String password) {
		return this.fac.authenticate(user, password);
	}

	@Override
	public boolean authorise(Request request, Method method, Auth auth) {
		return this.fac.authorise(request, method, auth);
	}

	@Override
	public Object authenticate(DigestResponse digestRequest) {
		return this.fac.authenticate(digestRequest);
	}

	@Override
	public String checkRedirect(Request request) {
		return null;
	}

	@Override
	public String getRealm() {
		return this.fac.getREALM();
	}

	@Override
	public String getUniqueId() {
		return (this.file.getAbsolutePath()+""+this.getModifiedDate()).hashCode()+"";
	}

	@Override
	public Date getCreateDate() {
		return new Date( this.file.lastModified() );
	}

	public void moveTo(CollectionResource newParent, String newName) {
		if( newParent instanceof FolderResource ) {
			FolderResource newFsParent = (FolderResource) newParent;
			File dest = new File(newFsParent.file, newName);
			boolean ok = this.file.renameTo(dest);
			if( !ok ) throw new RuntimeException("Failed to move to: " + dest.getAbsolutePath());
			this.file = dest;
		} else
			throw new RuntimeException("Destination is an unknown type. Must be a FsDirectoryResource, is a: " + newParent.getClass());
	}

	@Override
	public Date getModifiedDate() {
		return new Date( this.file.lastModified() );
	}

	protected abstract void doCopy(File dest);
	public void copyTo(CollectionResource newParent, String newName) {
		if( newParent instanceof FolderResource ) {
			FolderResource newFsParent = (FolderResource) newParent;
			File dest = new File(newFsParent.file, newName);
			this.doCopy(dest);
		} else
			throw new RuntimeException("Destination is an unknown type. Must be a FsDirectoryResource, is a: " + newParent.getClass());
	}

	@Override
	public void delete() {
		if (!this.file.delete())
			throw new SecurityException("not deleted: " + this.file);
	}

	@Override
	public String getName() {
		return this.file.getName();
	}

}
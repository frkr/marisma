package marisma;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;

import marisma.output.OutputJSON;
import marisma.output.OutputXML;
import marisma.output.OutputXSLT;

import org.jdom.JDOMException;
import org.json.JSONObject;

/**
 * <pre>
 * Camada de Negocios para ser usado apenas com retornos em XML
 * outros maneiras de usar exemplo:
 * http://www.marisma.com.br/servlet?role=teste&output=xml
 * http://www.marisma.com.br/servlet?role=teste&output=json
 * 
 * as saidas s�o:
 * json
 * xml
 * xslt
 * </pre>
 * @author davimesquita@gmail.com
 */
public abstract class BizRoleAbstractView extends BizRoleAbstract {

	@Override
	protected void out(Wrapper w, Method m, Output o) throws ServletException, IOException {
		OutputXML xml=null;
		try {
			xml = (OutputXML) o;
		} catch (Exception e) {
			throw new ServletException( this.getClass().getName() + " - OutputXML");
		}

		// TODO Testar
		if (w.getParameter("output") !=null) {
			if (w.getParameter("output").equals("json")) {
				w.out(new OutputJSON(new JSONObject(xml.getXML().getDocument())));
			} else if (w.getParameter("output").equals("xml")) {
				w.out(o);
			} else if (w.getParameter("output").equals("xslt") && m.isAnnotationPresent(View.class)) {
				View v = m.getAnnotation(View.class);
				try {
					w.out(new OutputXML(XMLData.openXML(w.webcontentFile(v.path()))));
				} catch (JDOMException e) {
					throw new ServletException( this.getClass().getName() + ":" + v.path(), e );
				}
			}
		}
		if(!w.isUsed() && m.isAnnotationPresent(View.class)) {
			View v = m.getAnnotation(View.class);
			w.out(new OutputXSLT(xml.getXML(), v.path()));
		} else {
			super.out(w, m, o);
		}
	}

}

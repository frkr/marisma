package marisma;

import java.lang.reflect.Method;

class BizRoleMethodImplGae implements BizRoleMethod {
	public Method getMethod(Class<?> clazz, String method) throws NoSuchMethodException {
		Method[] mts = clazz.getDeclaredMethods();
		for (Method linha: mts) {
			if (linha.getName().equals(method))
				return linha;
		}
		throw new NoSuchMethodException(method);
	}
}

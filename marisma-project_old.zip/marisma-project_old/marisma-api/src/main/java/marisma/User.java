package marisma;

import java.io.Serializable;

/**
 * @author davimesquita@gmail.com
 * <pre>
 * Precau��es
 * N�o pode existir um grupo com o nome de um usu�rio
 * Retornar uma instancia nova exemplo: Nova instancia de UserImpl
 * </pre>
 */
public interface User extends Serializable {

	/**
	 * <pre>
	 * Precau��es
	 * N�o pode existir um grupo com o nome de um usu�rio
	 * Retornar uma instancia nova exemplo: Nova instancia de UserImpl
	 * </pre>
	 * @param login usu�rio
	 * @param pass senha
	 * @return uma nova instancia da classe "User"
	 */
	public User newLogin(String login, String pass);
	/**
	 * {@link #newLogin(String, String)}
	 * @param login Usu�rio
	 * @return uma nova instancia
	 */
	public User newLogin(String login);
	/**
	 * 
	 * @param controller Servlet ou o Controller
	 * @param role Acesso ou parte do codigo
	 * @return se pode ter acesso ou n�o
	 */
	public boolean checkAccess(String controller, String role);

	/**
	 * @return String
	 */
	public String getLogin();
	/**
	 * @return String
	 */
	public String getPass();

}

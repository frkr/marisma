package marisma;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Camada de negocios
 * @author davimesquita@gmail.com
 */
public abstract class BizRoleAbstract extends HttpServlet implements Servlet {

	private static BizRoleMethod method;

	static {
		//		if (Wrapper.GAE) {
		//			BizRoleAbstract.method = new BizRoleMethodImplGae();
		//		} else {
		BizRoleAbstract.method = new BizRoleMethodImpl();
		//		}
	}
	private String getCommand() {
		return this.getServletConfig().getServletName();
	}
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.process(this.getCommand(),req, resp,this);
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.process(this.getCommand(),req, resp,this);
	}
	protected Method getMethod(String method) throws NoSuchMethodException {
		return BizRoleAbstract.method.getMethod(this.getClass(),method);
	}
	/**
	 * N�o sobregrave este method. Esta publico somente para uso futuro.
	 * @param controller String
	 * @param req Request
	 * @param resp Response
	 * @param serv Servlet
	 * @throws ServletException Exception
	 * @throws IOException Exception
	 */
	private void process(String controller, HttpServletRequest req, HttpServletResponse resp, Servlet serv) throws ServletException, IOException {
		Wrapper w = new Wrapper(controller,req,resp,serv);
		Object output = null;

		if (w.getRole().equals("")) {
			w.setRole("default");
		}

		try {
			Method m = this.getMethod( w.getRole() + "Role" );
			if (m.isAnnotationPresent(Secure.class)) {
				Secure sec = m.getAnnotation(Secure.class);
				boolean can=false;
				if (sec.byRole()) {
					can=w.checkAccess();
				} else {
					can=w.checkLogin();
				}
				if (!can)
					throw new ForbiddenException("Forbidden");
			}
			output = m.invoke(this, w);
			if (output!=null && !w.isUsed()) {
				this.out(w, m,(Output) output);
			}
		} catch (ForbiddenException f) {
			resp.sendError(HttpServletResponse.SC_FORBIDDEN);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(controller + "." + w.getRole() + "Role(): " + e.getMessage());
		}
	}
	protected void out(Wrapper w, Method m, Output o) throws ServletException, IOException {
		w.out(o);
	}
	/**
	 * <pre>
	 * URL
	 * ?role=default
	 * </pre>
	 * @param w {@link Wrapper}
	 * @return {@link Output}
	 * @throws ServletException {@link Output}
	 * @throws IOException {@link Output}
	 */
	public abstract Output defaultRole(Wrapper w) throws ServletException, IOException;

}

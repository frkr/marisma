package marisma;

import java.io.IOException;

import javax.servlet.ServletException;

/**
 * Interface para a cria��o de diferentes saidas do Marisma
 * @author davimesquita@gmail.com
 */
public interface Output {
	/**
	 * Metodo padr�o
	 * @param wrapper {@link Wrapper}
	 * @throws ServletException Retorne sempre que seu Output estiver configurado errado
	 * @throws IOException Retorne sempre que algo do sistema do servidor der errado.
	 */
	public void out(Wrapper wrapper) throws ServletException, IOException;
}

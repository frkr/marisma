package marisma;

import javax.servlet.ServletException;

/**
 * Controle de erro para acesso negado no marisma
 * @author davimesquita@gmail.com
 */
public class ForbiddenException extends ServletException {
	/**
	 * Construtor padr�o
	 * @param msg String
	 */
	public ForbiddenException(String msg) {
		super(msg);
	}
}

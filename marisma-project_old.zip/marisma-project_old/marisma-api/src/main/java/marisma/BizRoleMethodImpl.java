package marisma;

import java.lang.reflect.Method;

class BizRoleMethodImpl implements BizRoleMethod {
	public Method getMethod(Class<?> clazz, String method) throws SecurityException, NoSuchMethodException {
		return clazz.getDeclaredMethod(method, clazz);
	}
}

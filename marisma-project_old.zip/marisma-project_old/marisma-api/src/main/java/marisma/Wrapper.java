package marisma;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.logging.Logger;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Classe onde concentra todos os utilit�rios para o programador do Marisma.
 * @author davimesquita@gmail.com
 */
public class Wrapper {

	private static Logger log = Logger.getLogger(Wrapper.class.getName());
	/**
	 * Implementa��o de seguran�a
	 */
	public static User USERIMPL = new UserFake();
	/**
	 * Indica se o Google AppEngine esta presente
	 */
	//	public static boolean GAE = false;

	//	static {
	//		try {
	//			Thread.currentThread().getContextClassLoader().loadClass("org.datanucleus.store.appengine.jdo.DatastoreJDOPersistenceManagerFactory");
	//			Wrapper.GAE=true;
	//		} catch (Exception e) {
	//		}
	//		String prop = System.getProperty(Wrapper.class.getName()+".userimpl"); // FIXME Documentar / Alterar / Testar se o system propeties propaga atravez das JVM
	//		if (prop != null && prop.length() > 0) {
	//			try {
	//				Wrapper.USERIMPL = (User) Thread.currentThread().getContextClassLoader().loadClass(prop).newInstance();
	//			} catch (ClassNotFoundException e) {
	//				Wrapper.log.severe("Class not found: " + prop);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//				Wrapper.log.severe(e.getMessage());
	//			}
	//		}
	//		String usrmsg = "SystemPropertie: " + Wrapper.class.getName()+".userimpl=" + Wrapper.USERIMPL.getClass().getName();
	//		if (Wrapper.USERIMPL instanceof UserFake) {
	//			Wrapper.log.warning(usrmsg);
	//		} else {
	//			Wrapper.log.info(usrmsg);
	//		}
	//	}

	private User user=null;
	private HttpServletRequest req;
	private HttpServletResponse resp;
	private Servlet serv;
	private Boolean used=false;
	private String role;
	private Output output=null;
	private String controller;

	/**
	 * Retorna se o SERVLET foi usado
	 * @return boolean
	 */
	public boolean isUsed() {
		return this.used;
	}
	/**
	 * Configura se o SERVLET foi usado
	 * @param used boolean
	 */
	public void setUsed(boolean used) {
		this.used=used;
	}
	/**
	 * @return Output
	 * {@link Output}
	 */
	public Output getOutput() {
		return this.output;
	}
	/**
	 * {@link Output}
	 * @param output Output
	 */
	public void setOutput(Output output) {
		this.output = output;
	}
	/**
	 * @return Retorna o controle das Requisi��es do servlet
	 */
	public HttpServletRequest getRequest() {
		return this.req;
	}
	/**
	 * @return Retorna o controle da resposta do Servlet
	 */
	public HttpServletResponse getResponse() {
		return this.resp;
	}
	/**
	 * @return Retorna qual servlet em quest�o
	 */
	public Servlet getServlet() {
		return this.serv;
	}
	/**
	 * Construtor alternativo
	 * @see #Wrapper(String, HttpServletRequest, HttpServletResponse, Servlet, Output)
	 * @param req Request
	 * @param resp Response
	 * @param serv Servlet
	 */
	public Wrapper(HttpServletRequest req, HttpServletResponse resp, Servlet serv) {
		this(serv.getServletConfig().getServletName(),req,resp,serv,null);
	}
	/**
	 * Construtor alternativo
	 * @see #Wrapper(String, HttpServletRequest, HttpServletResponse, Servlet, Output)
	 * @param req Request
	 * @param resp Response
	 * @param serv Servlet
	 * @param output {@link Output}
	 */
	public Wrapper(HttpServletRequest req, HttpServletResponse resp, Servlet serv, Output output) {
		this(serv.getServletConfig().getServletName(),req,resp,serv,output);
	}
	/**
	 * Construtor alternativo
	 * @see #Wrapper(String, HttpServletRequest, HttpServletResponse, Servlet, Output)
	 * @param controller Nome do Servlet ou Controller em questao.
	 * @param req Request
	 * @param resp Response
	 * @param serv Servlet
	 */
	public Wrapper(String controller, HttpServletRequest req, HttpServletResponse resp, Servlet serv) {
		this(controller,req,resp,serv,null);
	}
	/**
	 * Ponto de entrada para as ferramentas do Marisma
	 * 
	 * Pode ser feito o login ate mesmo ao chamar esta classe. Exemplo:
	 * http://www.marisma.com.br/servlet?login=admin&pass=words
	 * 
	 * @param controller Servlet ou nome do Controller
	 * @param req Requisi��es HTTP
	 * @param resp Resposta HTTP
	 * @param serv Servlet em quest�o.
	 * @param output Output para saida de informa��es para o Respose. pode ser declarado nulo.
	 */
	public Wrapper(String controller, HttpServletRequest req, HttpServletResponse resp, Servlet serv, Output output) {
		this.controller=controller;
		this.req=req;
		this.resp=resp;
		this.serv=serv;
		this.output=output;
		String tgt = req.getParameter("role");
		if (tgt==null) {
			tgt="";
		}
		this.role=tgt;
		try {
			this.user = (User) req.getSession(false).getAttribute("marisma::user");
		} catch (Exception e) {
		}
		if (this.user==null
				&& req.getParameter("login") != null
				&& !req.getParameter("login").equals("")
				&& req.getParameter("pass") != null
				&& !req.getParameter("pass").equals("")
		) {
			this.userLogin(req.getParameter("login"), req.getParameter("pass"));
		}
	}
	/**
	 * @param r Configura qual Role, parte do codigo ou alvo.
	 */
	public void setRole(String r) {
		this.role=r;
	}
	/**
	 * @see #setRole(String)
	 * @return String
	 */
	public String getRole() {
		return this.role;
	}
	/**
	 * @see #setController(String)
	 * @return String
	 */
	public String getController() {
		return this.controller;
	}
	/**
	 * @param controller O nome simples do Servlet ou controller
	 */
	public void setController(String controller) {
		this.controller = controller;
	}
	/**
	 * Retorna o usu�rio logado ou null
	 * @return User
	 */
	public User getUser() {
		return this.user;
	}
	/**
	 * Utilitario para encontrar arquivos desde a raiz do projeto
	 * @param file Arquivo relativo
	 * @return File
	 */
	public File webcontentFile(String file) {
		return new File(Wrapper.webcontentPath(this.serv.getServletConfig()) + "/" + file);
	}
	/**
	 * @param s Servlet
	 * @return Path relativo
	 */
	public static String webcontentPath(ServletConfig s) {
		return s.getServletContext().getRealPath("/");
	}
	/**
	 * Saida do wrapper. Ultimo feito do wrapper no Servlet
	 * @see #out()
	 * @param output {@link Output}
	 * @throws ServletException Exception
	 * @throws IOException Exception
	 */
	public void out(Output output) throws ServletException, IOException {
		this.output=output;
		this.out();
	}
	/**
	 * {@link Output}
	 * @throws ServletException Se o servlet j� foi usado, a variavel isUsed ou se o Output n�o esta configurado
	 * @throws IOException A interface output pode retornar esta exce��o
	 */
	public void out() throws ServletException, IOException {
		if (this.used) throw new ServletException("Servlet - Wrapper isUsed");
		if (this.output==null) throw new ServletException("Output Interface - not set");
		this.output.out(this);
		this.used=true;
	}
	/**
	 * Metodo de LOGIN
	 * @return Se o login ou senha funciona
	 * @param login Usu�rio
	 * @param pass Senha
	 */
	public boolean userLogin(String login, String pass) {
		if (Wrapper.USERIMPL==null) return false;
		User logado = Wrapper.USERIMPL.newLogin(login, pass);
		if (logado==null) return false;
		this.user=logado;
		this.req.getSession(true).setAttribute("marisma::user", this.user);
		return true;
	}
	/**
	 * Metodo de LOGOFF
	 */
	public void userLogout() {
		this.user=null;
		this.req.getSession(false).setAttribute("marisma::user", null);
	}
	/**
	 * {@link HttpServletRequest#getParameter(String)}
	 * Exemplo
	 * http://www.marisma.com.br/servlet?parametro=valor
	 * @return String
	 * @param param Valor
	 */
	public String getParameter(String param) {
		return this.req.getParameter(param);
	}
	/**
	 * Exemplo:
	 * http://www.marisma.com.br/servlet?parametro=um&parametro=dois
	 * {@link HttpServletRequest#getParameterValues(String)}
	 * @param param Parametro
	 * @return String[] Valores
	 */
	public String[] getParameterValues(String param) {
		return this.req.getParameterValues(param);
	}
	/**
	 * Verifica se o usuario tem permissao para uma acao
	 * @return boolean
	 */
	public boolean checkAccess() {
		if (this.user==null) return false;
		return this.user.checkAccess(this.controller,this.role);
	}
	/**
	 * Verifica se o usuario tem permissao para uma acao
	 * @return boolean
	 * @param controller Servlet, command ou controller em quest�o
	 * @param role Acesso, metodo ou parte do codigo em quest�o
	 */
	public boolean checkAccess(String controller, String role) {
		if (this.user==null) return false;
		return this.user.checkAccess(controller,role);
	}
	/**
	 * Verifica se o usuario esta logado
	 * @return boolean
	 */
	public boolean checkLogin() {
		if (this.user!=null)
			return true;
		return false;
	}
	/**
	 * @see #populate(Class)
	 * @param jdo Objeto Getter and Setter
	 * @return Uma nova instancia do objeto
	 * @throws ServletException Se usado incorretamente
	 */
	public Object populate(Populate jdo) throws ServletException {
		return this.populate(jdo.getClass());
	}
	/**
	 * Pega os valores no formulario em objetos Getter and Setter
	 * @param jdo Objeto Getter and Setter
	 * @return Uma nova instancia do objeto
	 * @throws ServletException Se usado incorretamente
	 * {#link Populate} Interface
	 */
	public Object populate(Class<? extends Populate> jdo) throws ServletException { // TODO Talvez n�o funciona no GAE
		Object ret=null;
		try {
			ret = jdo.newInstance();
			for (Field field: jdo.getDeclaredFields()) {
				//field.isAnnotationPresent(Persistent.class) &&
				if (this.req.getParameter(field.getName()) != null) {
					Object obj = this.req.getParameter(field.getName());

					// Detecta e valida os campos
					if (field.getType().equals(String.class)) {
						obj = obj.toString();
					} else if (field.getType().equals(Long.class)) {
						obj = Long.parseLong(obj.toString());
					} else if (field.getType().equals(Integer.class)) {
						obj = Integer.parseInt(obj.toString());
					} else if (field.getType().equals(Double.class)) {
						obj = Double.parseDouble(obj.toString());
					} else {
						try {
							Method m = ret.getClass().getDeclaredMethod("populate", Field.class, String.class);
							obj = m.invoke(ret,field, obj.toString());
						} catch (Exception e) {
						}
					}

					try {
						field.setAccessible(true);
						field.set(ret, obj);
					} catch (Exception e) {
						Wrapper.log.warning("not populated - " +jdo.getName() + "." + field.getName());
					}
				}
			}
		} catch (Exception ee) {
			throw new ServletException("populate - " + jdo.getName());
		}
		return ret;
	}
}

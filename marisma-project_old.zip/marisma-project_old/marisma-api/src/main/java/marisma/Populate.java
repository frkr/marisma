package marisma;

import java.lang.reflect.Field;

/**
 * Para popular classes getters and setters
 * @author davimesquita@gmail.com
 */
public interface Populate {
	/**
	 * Use sempre este metodo quando n�o ouver compativeis simples. O Marisma tenta descobrir: String, Long, Double e Integer
	 * @param field Campo
	 * @param value Valor
	 * @return retorna o objeto puro para o campo
	 */
	public Object populate(Field field, String value);
}

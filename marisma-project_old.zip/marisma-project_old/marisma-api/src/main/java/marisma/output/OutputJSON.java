package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author davimesquita@gmail.com
 */
public class OutputJSON implements Output {

	private JSONObject json;
	private int ident=1;
	/**
	 * @return JSONObject
	 */
	public JSONObject getJSON() {
		return this.json;
	}
	/**
	 * @param json JSONObject
	 */
	public void setJSON(JSONObject json) {
		this.json = json;
	}
	/**
	 * @return nivel de identa��o
	 */
	public int getIdent() {
		return this.ident;
	}
	/**
	 * @param ident nivel de identa��o
	 */
	public void setIdent(int ident) {
		this.ident = ident;
	}
	/**
	 * Construtor
	 * @param json JSONObject
	 */
	public OutputJSON(JSONObject json) {
		this.json=json;
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		try {
			wrapper.getResponse().setContentType("application/json");
			wrapper.getResponse().getWriter().print(this.json.toString(this.ident));
		} catch (JSONException e) {
			throw new IOException(e.getMessage());
		}
	}

}

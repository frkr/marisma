package marisma.output;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;
import marisma.XMLData;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.transform.XSLTransformException;
import org.jdom.transform.XSLTransformer;

/**
 * @author davimesquita@gmail.com
 * <pre>
 * Usando GAE (Google App Engine) deve-se usar o SAXON
 * 
 * O uso de Saxon � opcional. Porem existem alguns softwares de XLST que n�o s�o compativeis com a implementa��o nativa do java.
 * 
 * Talvez em alguns XSL para o Dreamweaver CS3 tenha que usar o Saxon e + esta linha (( colocar logo apos: <xsl:stylesheet...> ))
 * <xsl:output method="html" encoding="utf-8" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
 *
 * <pre>
 */
public class OutputXSLT implements Output {

	static {
		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
	}

	private String xslt;
	private XMLData xmld;
	private Format format = Format.getCompactFormat();

	/**
	 * @return String path do XSLT
	 */
	public String getXSLT() {
		return this.xslt;
	}
	/**
	 * @param xslt path do XSLT
	 */
	public void setXSLT(String xslt) {
		this.xslt = xslt;
	}
	/**
	 * @return XMLData arquivo XML para convers�o
	 */
	public XMLData getXML() {
		return this.xmld;
	}
	/**
	 * @param xml XMLData arquivo XML para convers�o
	 */
	public void setXML(XMLData xml) {
		this.xmld=xml;
	}
	/**
	 * {@link XMLData#getXML(Format)}
	 * @return retorna qual tipo de formato.
	 */
	public Format getFormat() {
		return this.format;
	}
	/**
	 * {@link XMLData#getXML(Format)}
	 * @param format jdom Format
	 */
	public void setFormat(Format format) {
		this.format = format;
	}
	/**
	 * Construtor
	 * @param data arquivo XML para convers�o
	 * @param xsl path do arquivo para o template XSL
	 */
	public OutputXSLT(XMLData data, String xsl) {
		this.xslt=xsl;
		this.xmld=data;
	}
	/**
	 * Convers�o de XML usando XSLT
	 * @param file XSLTransformer � um objeto do JDOM que pode ler arquivos de diversos tipos.
	 * @param xml Documento XML em JDOM
	 * @return uma instacia do XMLData que contem v�rios utilit�rios
	 * {@link XMLData#getXML(Format)}
	 * @throws XSLTransformException Aponta a linha e coluna de onde o XSLT deu problema.
	 */
	public static XMLData transform(XSLTransformer file, Document xml) throws XSLTransformException {
		return new XMLData(file.transform(xml));
	}

	public void out(Wrapper wrapper) throws ServletException, IOException {
		try {
			File file = wrapper.webcontentFile(this.xslt);
			if (!file.exists()) throw new ServletException("XSL not found - " + this.xslt);

			wrapper.getResponse().setContentType("text/html");
			wrapper.getResponse().getOutputStream().print(
					OutputXSLT.transform(new XSLTransformer(file), this.xmld.getDocument()).getXML(this.format)
			);
		} catch (XSLTransformException e) {
			throw new IOException(e.getMessage() + " " + e.getCause());
		}
	}

}

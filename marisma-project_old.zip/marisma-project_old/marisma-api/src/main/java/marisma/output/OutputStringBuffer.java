package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

/**
 * Exemplo usando Stringbuffer para saida no Marisma
 * @author davimesquita@gmail.com
 */
public class OutputStringBuffer implements Output {

	private StringBuffer stringBuffer;
	private String contentType = "text/plain";

	/**
	 * @return StringBuffer
	 */
	public StringBuffer getStringBuffer() {
		return this.stringBuffer;
	}
	/**
	 * @param out StringBuffer
	 */
	public void setStringBuffer(StringBuffer out) {
		this.stringBuffer = out;
	}
	/**
	 * Construtor
	 * @param out StringBuffer
	 */
	public OutputStringBuffer(StringBuffer out) {
		this.stringBuffer=out;
	}
	/**
	 * Construtor alternativo
	 * @param out String
	 */
	public OutputStringBuffer(String out) {
		this(new StringBuffer(out));
	}
	/**
	 * Ao usar o StringBuffer se acredita que o conteudo ser� "text/plain"
	 * @return String
	 */
	public String getContentType() {
		return this.contentType;
	}
	/**
	 * @see #getStringBuffer()
	 * @param contentType "text/plain" O Mimetype da saida
	 */
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		wrapper.getResponse().setContentType(this.contentType);
		wrapper.getResponse().getWriter().print(this.stringBuffer);
	}

}

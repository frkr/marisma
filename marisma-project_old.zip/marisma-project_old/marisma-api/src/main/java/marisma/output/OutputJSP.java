package marisma.output;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

/**
 * Exemplo usando JSP no Marisma
 * @author davimesquita@gmail.com
 */
public class OutputJSP implements Output {

	private String jsp;
	private Map<String,Object> vo = new HashMap<String,Object>();

	/**
	 * @return String path JSP
	 */
	public String getJSP() {
		return this.jsp;
	}
	/**
	 * @param jsp path JSP
	 */
	public void setJSP(String jsp) {
		this.jsp = jsp;
	}
	/**
	 * configurar uma s�rie de VO's ( arquivos getters and setters )
	 * @param vo Map<String, Object>
	 */
	public void setVO(Map<String, Object> vo) {
		this.vo = vo;
	}
	/**
	 * @return retorna toda a s�rie de VO's ( arquivos getters and setters )
	 */
	public Map<String, Object> getVO() {
		return this.vo;
	}
	/**
	 * Construtor
	 * @param jsp path relativo ao webcontent do JSP
	 */
	public OutputJSP(String jsp) {
		this.jsp=jsp;
	}
	/**
	 * Construtor
	 * @param jsp path relativo do webcontent do JSP
	 * @param vo op��o para configurar apenas um VO ( arquivos getters and setters )
	 */
	public OutputJSP(String jsp, Object vo) {
		this(jsp);
		this.setVO(vo);
	}
	public void out(Wrapper wrapper) throws ServletException, IOException {
		for (String linha: this.vo.keySet()) {
			wrapper.getRequest().setAttribute(linha, this.vo.get(linha));
		}
		wrapper.getRequest().getRequestDispatcher(this.jsp).forward(wrapper.getRequest(), wrapper.getResponse());
	}
	/**
	 * Informar um VO ( arquivos getters and setters )
	 * @param name nome do VO para ser resgatado usando
	 * <code>
	 * 	<jsp:useBean id="nome" class="java.util.HashMap" scope="request" />
	 * </code>
	 * @param obj O proprio VO
	 */
	public void setVO(String name, Object obj) {
		this.vo.put(name, obj);
	}
	/**
	 * Enviar um VO ( arquivos getters and setters )
	 * @param object Usa-se o nome simples da Classe para ser resgatado.
	 *	<code>
	 * 	<jsp:useBean id="HashMap" class="java.util.HashMap" scope="request" />
	 * 	</code>
	 */
	public void setVO(Object object) {
		this.setVO(object.getClass().getSimpleName(),object);
	}

}

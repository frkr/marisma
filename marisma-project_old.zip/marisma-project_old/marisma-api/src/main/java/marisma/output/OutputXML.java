package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;
import marisma.XMLData;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 * Exemplo de retorno para usar no Marisma
 * @author davimesquita@gmail.com
 */
public class OutputXML implements Output {

	private XMLData xml;
	private Format format = Format.getCompactFormat();

	/**
	 * {@link XMLData#getXML(Format)}
	 * @return Format
	 */
	public Format getFormat() {
		return this.format;
	}
	/**
	 * {@link XMLData#getXML(Format)}
	 * @param format Format
	 */
	public void setFormat(Format format) {
		this.format = format;
	}
	/**
	 * @return Retorna o Documento JDOM
	 */
	public XMLData getXML() {
		return this.xml;
	}
	/**
	 * @param xml Configurar o Documento JDOM
	 */
	public void setXML(XMLData xml) {
		this.xml = xml;
	}
	/**
	 * Construtor
	 * @param xml XMLData
	 */
	public OutputXML(XMLData xml) {
		this.xml=xml;
	}
	/**
	 * Construtor alternativo para o JDOM
	 * @param xml XMLData
	 */
	public OutputXML(Document xml) {
		this(new XMLData(xml));
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		wrapper.getResponse().setContentType("application/xml");
		wrapper.getResponse().getWriter().print(new XMLOutputter(this.format).outputString(this.xml.getDocument()));
	}

}

package marisma;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jdom.CDATA;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Text;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 * Classe apenas para facilitar ainda mais o uso do JDOM
 * @author davimesquita@gmail.com
 */
public class XMLData implements Serializable {
	private Document xml;
	private Element root;
	private List<Element> group = new ArrayList<Element>();
	private Element tag=null;

	/**
	 * Construtor padr�o
	 */
	public XMLData() {
		this("document");
	}
	/**
	 * Construtor configurando o root
	 * @param root String
	 */
	public XMLData(String root) {
		this(new Element(root));
	}
	/**
	 * Construtor alternativo para usar com o JDOM
	 * @param root Elemento dentro do JDOM
	 */
	public XMLData(Element root) {
		this.xml = new Document();
		this.root = root;
		this.xml.addContent(this.root);
	}
	/**
	 * Construtor alternativo para usar JDOM
	 * @param doc JDOM Document
	 */
	public XMLData(Document doc) {
		this.setDocument(doc);
	}
	/**
	 * Configurar o XMLData usando JDOM
	 * @param doc JDOM Document
	 */
	public void setDocument(Document doc) {
		this.xml=doc;
		if (this.xml.hasRootElement()) {
			this.root=this.xml.getRootElement();
		} else {
			this.root=new Element("document");
			this.xml.addContent(this.root);
		}
	}
	/**
	 * @return Retorna o Documento JDOM
	 */
	public Document getDocument() {
		return this.xml;
	}
	/**
	 * @return A Vers�o pura do XML
	 * @see #getXML(Format)
	 */
	public String getXML() {
		return this.getXML(Format.getPrettyFormat());
	}
	/**
	 * <pre>
	 * 	Configurando o tipo de formato podemos ter uma vers�o mais legivel ou, por exemplo, uma vers�o em outro "encoding"
	 * exemplo: Em ISO 8859-1
	 * 	<code>
	 * 	getXML(Format.getPrettyFormat().setEncoding("iso-8859-1"));
	 * 	</code>
	 * </pre>
	 * @param format Informe o tipo de saida
	 * @return String
	 */
	public String getXML(Format format) {
		XMLOutputter xml = new XMLOutputter(format);
		return xml.outputString(this.xml);
	}
	/**
	 * Exemplo: <tag>valor</tag>
	 * @param name nome da TAG
	 * @param value valor
	 * @param cdata Dados puros. Pode ser bin�rio.
	 */
	public void addClosedTag(String name, String value, boolean cdata) {
		Element ele = new Element(name);
		ele.addContent(cdata ? new CDATA(value) : new Text(value));
		this.addGroupElement(ele);
	}
	/**
	 * Exemplo: <tag>valor</tag>
	 * @param name String
	 * @param value String
	 * @see #addClosedTag(String, String, boolean)
	 */
	public void addClosedTag(String name, String value) {
		this.addClosedTag(name, value, false);
	}
	/**
	 * Exemplo <nome parametro="valor" />
	 * @see #addParameterTag(String)
	 * @param name Parametro
	 */
	public void addParameterTag(String name) {
		this.tag=new Element(name);
		this.addGroupElement(this.tag);
	}
	/**
	 * Exemplo <nome parametro="valor" />
	 * @param name parametro
	 * @param value valor
	 * @see #addParameterTag(String)
	 */
	public void addParameter(String name, String value) {
		if (this.tag==null) {
			this.addParameterTag("record");
		}
		this.tag.setAttribute(name, value);
	}
	/**
	 * Abre um grupo exemplo:
	 * <code>
	 * 	<grupo>
	 * 		<outras_tags>valor</outras_tags>
	 * 	</grupo>
	 * </code>
	 * @param name nome da tag
	 */
	public void openGroup(String name) {
		Element ele = new Element(name);
		this.addGroupElement(ele);
		this.group.add(ele);
	}
	/**
	 * Fecha o grupo
	 * @see #openGroup(String)
	 */
	public void closeGroup() {
		if (this.group.size()>0) {
			this.group.remove(this.group.size()-1);
		}
	}

	private void addGroupElement(Element ele) {
		if (this.group.size()==0) {
			this.root.addContent(ele);
		} else {
			this.group.get(this.group.size()-1).addContent(ele);
		}
	}
	/**
	 * Abre um arquivo XML. Usa-se uma engine SAX e n�o uma DOM.
	 * @param xml arquivo xml
	 * @return Documento JDOM
	 * @throws JDOMException Se o arquivo xml esta mal construido
	 * @throws IOException Se n�o pode ler o arquivo
	 */
	public static Document openXML(File xml) throws JDOMException, IOException {
		return new SAXBuilder().build(xml);
	}
	/**
	 * Alternativa para o @see #openXML(File)
	 * @param xml InputStream
	 * @return JDOM Document
	 * @throws JDOMException Exception
	 * @throws IOException Exception
	 */
	public static Document openXML(InputStream xml) throws JDOMException, IOException {
		return new SAXBuilder().build(xml);
	}

}
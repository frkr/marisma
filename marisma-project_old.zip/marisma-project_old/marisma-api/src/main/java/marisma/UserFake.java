package marisma;

import java.util.logging.Logger;

/**
 * Uma implementa��o falsa de seguran�a do Marisma.
 * Sempre dar� autoriza��o para todos.
 * @author davimesquita@gmail.com
 */
public class UserFake implements User {
	private static Logger log = Logger.getLogger(UserFake.class.getName());

	private String login="admin";
	private String pass="admin";

	public boolean checkAccess(String command, String role) {
		UserFake.log.warning("not secure: " + Wrapper.class.getName());
		return true;
	}

	public User newLogin(String login, String pass) {
		UserFake.log.warning("not secure: " + Wrapper.class.getName());
		if (this.login.equals(login) && this.pass.equals(pass))
			return new UserFake();
		return null;
	}

	@Override
	public String getLogin() {
		return this.login;
	}

	@Override
	public String getPass() {
		return this.pass;
	}

	@Override
	public User newLogin(String login) {
		UserFake.log.warning("not secure: " + Wrapper.class.getName());
		if (login.equals(this.login))
			return new UserFake();
		return null;
	}

}

package marisma;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;


public class PMF {
	//	/**
	//	 * Retorna a proxima primarykey. Se a implementa��o estiver vazia: Retorna null
	//	 */
	//	public static synchronized Long getNextId() {
	//		//if (Wrapper.primarykeyimpl==null) return null;
	//		return Wrapper.primarykeyimpl.getNextId();
	//	}
	public static PersistenceManager getPersistence(Database database) {
		return PMF.getPersistence(database.getDatabase()); // TODO ver o ehcache
	}
	public static PersistenceManager getPersistence(String database) {
		return JDOHelper.getPersistenceManagerFactory(database).getPersistenceManager();
	}
	public static synchronized Long getNextId() {
		return System.currentTimeMillis();
	}
}

package controller;

import javax.servlet.ServletException;

import marisma.BizRoleAbstract;
import marisma.Output;
import marisma.Secure;
import marisma.Wrapper;
import marisma.XMLData;
import marisma.output.OutputXSLT;

/**
 * Sample
 */
public class BizTest extends BizRoleAbstract {
	public String PAGE_HOME = "view/servletBiz.xsl";

	@Override
	@Secure
	public Output defaultRole(Wrapper w) throws ServletException {
		XMLData data = new XMLData();
		data.addClosedTag("msg", w.getRole() + ": Funciona");
		return new OutputXSLT(data,this.PAGE_HOME);
	}

}

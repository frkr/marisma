package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.Wrapper;
import marisma.output.OutputJSP;

/**
 * Sample
 */
public class JspTest extends HttpServlet implements Servlet {
	private String PAGE_TEST = "view/jspTest.jsp";

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Wrapper wrapper = new Wrapper(req,resp,this);

		Map<String,String> data = new HashMap<String, String>();
		data.put("msg", "Funciona");

		OutputJSP jsp = new OutputJSP(this.PAGE_TEST);
		jsp.setVO("data",data);
		wrapper.out(jsp);
	}

}

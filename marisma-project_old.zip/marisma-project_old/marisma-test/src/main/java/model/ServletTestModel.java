package model;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;

import marisma.Populate;

/**
 * Sample
 */
public class ServletTestModel implements Populate {

	private Long id;
	private String nome="";
	private Date data=new Date();

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getData() {
		return this.data;
	}
	public void setData(Date data) {
		this.data = data;
	}

	public Object populate(Field field, String value) {
		if (field.getType().equals(Date.class)) {
			try {
				return new SimpleDateFormat("dd/MM/yyyy").parse(value);
			} catch (Exception e) {
			}
		}
		return null;
	}

}
package marisma.war;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Logger;

import marisma.UserFake;
import marisma.XMLData;
import marisma.filter.ResponseTrap;
import marisma.framework.SQL;
import marisma.mysql.ConnectionWrapper;

import org.jdom.output.Format;

public class MySQL implements SQL {
	private static Logger log = Logger.getLogger(UserFake.class.getName());

	static {
		try {
			Thread.currentThread().getContextClassLoader().loadClass("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
			MySQL.log.severe(e.getMessage());
		}
	}

	// FIXME Fazer a intercepta��o do .sql
	@Override
	public void call() {
		XMLData data = new XMLData();
		int sqls=1;
		try {
			ResponseTrap ptrap = ResponseTrap.getTrapThread();
			Connection conn = new ConnectionWrapper(DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root", ""));

			Statement st = conn.createStatement();
			st.execute(ptrap.getTrap().toString()); // FIXME java.sql.SQLException: Can not issue empty query.

			ResultSet rs = st.getResultSet();
			ResultSetMetaData mt = rs.getMetaData();

			// FIXME Tags (nodos) n�o podem ter parenteses e nem caracteres especiais
			data.openGroup("sql" + sqls++);
			String table="";
			while (rs.next()) {
				if (!mt.getCatalogName(1).equals(table)) {
					table=mt.getCatalogName(1);
					if (!mt.getCatalogName(1).equals("")) {
						data.closeGroup();
					}
					data.openGroup(mt.getCatalogName(1));
				}
				data.openGroup("record");
				for (int i=1;i<=mt.getColumnCount();i++) {
					data.addClosedTag(mt.getColumnName(i), rs.getString(i), true);
				}
				data.closeGroup();
			}
			data.closeGroup();
			conn.close();

			ptrap.setContentType("text/html");
			ptrap.getWriterReal().print(data.getXML(Format.getPrettyFormat()));

		} catch (Exception e) {
			e.printStackTrace();
			MySQL.log.severe(e.getMessage());
		}
	}

	@Override
	public void reconfigure(Properties prop) {
		// FIXME Auto-generated method stub
	}

}

package marisma.war;

// FIXME FAZER
public class User extends marisma.UserFake {

}

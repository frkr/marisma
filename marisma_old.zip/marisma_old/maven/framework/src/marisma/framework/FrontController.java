package marisma.framework;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.logging.Logger;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Ponto de entrada do Framework
 * @author davimesquita@gmail.com
 */
public class FrontController implements javax.servlet.Filter {

	private static Logger log = Logger.getLogger(FrontController.class.getName());

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,FilterChain filter) throws IOException, ServletException {
		Servlet s=null;
		try {
			Field f1 = filter.getClass().getDeclaredField("servlet"); // TODO Talvez n�o funcione no GAE
			f1.setAccessible(true);
			s = (Servlet) f1.get(filter);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = "Marisma Framework: " + e.getMessage();
			FrontController.log.severe(msg);
			throw new ServletException(msg);
		}
		HttpServletRequest r = (HttpServletRequest) req;
		HttpServletResponse p = (HttpServletResponse) resp;
		//		VFS.webcontent(r,p,s,file);
		if (r.getRequestURI().endsWith(".do")) {
			try {

				String uri = r.getRequestURI().substring(r.getRequestURI().indexOf("/", 1)+1,r.getRequestURI().indexOf(".do"));
				//Marisma.framework(uri, r, p, s);
				System.out.println("Marisma.framework("+uri+", "+r+", "+p+", "+s+");");
				//			} catch (MarismaException e) {
				//				e.printStackTrace();
				//				throw new ServletException(e.getMessage());
				//			} catch (ForbiddenException e) {
				//				p.sendError(HttpServletResponse.SC_FORBIDDEN);
			} catch (Exception e) {
				throw new ServletException(r.getRequestURI() + ":" + e.getMessage());
			}
		} else {
			// Se n�o existir no Framework. Delegar para o Tomcat:
			filter.doFilter(req, resp);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

}

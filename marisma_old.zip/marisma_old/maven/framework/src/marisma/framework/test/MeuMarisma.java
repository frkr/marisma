package marisma.framework.test;

import java.util.logging.Logger;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;

import marisma.framework.FrontController;
import marisma.framework.vfs.VFS;

/**
 * @author davimesquita@gmail.com
 */
public class MeuMarisma extends FrontController {

	private static Logger log = Logger.getLogger(MeuMarisma.class.getName());

	@Override
	public void init(FilterConfig c) throws ServletException {
		MeuMarisma.log.severe("N�o use esta classe. Crie sua pr�pria. - " + this.getClass().getName());
		//vfs.setLogger(log); // TODO Talvez tenha que adicionar a classe commons logging ou deletar essa linha
		//vfs.setReplicator(replicator); // TODO Criar wiki dizendo sobre o replicador
		try {
			//			VFS.vfs.addProvider("marisma", new MarismaVFS(VFS.vfs.resolveFile(Wrapper.webcontentPath(c.getServletContext())), "", new FileSystemOptions()));
			VFS.vfs.init();
		} catch (Exception e) {
			e.printStackTrace();
			MeuMarisma.log.severe(VFS.vfs.getClass().getName());
			throw new ServletException(VFS.vfs.getClass().getName());
		}
	}

}

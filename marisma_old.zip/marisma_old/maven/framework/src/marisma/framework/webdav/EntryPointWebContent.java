package marisma.framework.webdav;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServlet;

/**
 * @author davimesquita@gmail.com
 */
public class EntryPointWebContent extends HttpServlet implements Servlet {
	// TODO Sample
}

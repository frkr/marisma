package marisma.framework.vfs;

import org.apache.commons.vfs.FileName;
import org.apache.commons.vfs.FileSystemOptions;
import org.apache.commons.vfs.provider.local.LocalFileSystem;

public class MarismaVFS extends LocalFileSystem {

	public MarismaVFS(FileName rootName, String rootFile, FileSystemOptions opts) {
		super(rootName, rootFile, opts);
	}

}

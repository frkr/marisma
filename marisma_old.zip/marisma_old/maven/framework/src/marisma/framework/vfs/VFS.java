package marisma.framework.vfs;

import org.apache.commons.vfs.impl.DefaultFileSystemManager;


/**
 * Fachada para o Marisma
 * @author davimesquita@gmail.com
 */
public class VFS {

	public static DefaultFileSystemManager vfs = new DefaultFileSystemManager();

	private VFS(){}

}

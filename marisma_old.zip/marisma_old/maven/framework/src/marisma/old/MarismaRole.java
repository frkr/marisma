package marisma.old;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;
import javax.jdo.annotations.Unique;

import marisma.Database;

@PersistenceCapable
@Unique(name="FULL_IDX", members={"command", "role"})
public class MarismaRole implements Database {

	public String getDatabase() {
		return "Marisma";
	}

	@PrimaryKey
	@Persistent
	private Long id=null;
	@Persistent
	private Long command=null;
	@Persistent
	private String role=null;
	@Persistent
	private Integer access=null;
	@Persistent
	private String output=null;
	@Persistent
	private String resource=null;
	@Persistent
	private StringBuffer sql=null;

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCommand() {
		return this.command;
	}
	public void setCommand(Long command) {
		this.command=command;
	}
	public String getRole() {
		return this.role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * <pre>
	 * 0 Public
	 * 1 login
	 * 2 byRole
	 * </pre>
	 */
	public Integer getAccess() {
		return this.access;
	}
	/**
	 * <pre>
	 * 0 Public
	 * 1 login
	 * 2 byRole
	 * </pre>
	 */
	public void setAccess(Integer access) {
		this.access = access;
	}
	public String getOutput() {
		return this.output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getResource() {
		return this.resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
	public StringBuffer getSql() {
		return this.sql;
	}
	public void setSql(StringBuffer sql) {
		this.sql = sql;
	}

}

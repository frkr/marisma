package marisma.old;

import marisma.XMLData;

public interface Output extends marisma.Output {
	public void setXML(XMLData xml);
	public void setResource(String resource);
}

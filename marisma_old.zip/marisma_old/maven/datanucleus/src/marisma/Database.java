package marisma;

/**
 * @author davimesquita@gmail.com
 */
public interface Database {
	/**
	 * {@link PMF}
	 * @return String
	 */
	public String getDatabase();
}

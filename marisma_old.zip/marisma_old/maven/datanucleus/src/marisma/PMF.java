package marisma;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;

/**
 * Wrapper comum para o Datanucleus
 * @author davimesquita@gmail.com
 */
public class PMF {
	/**
	 * @return System.currentTimeMillis();
	 */
	public static synchronized Long getNextId() {
		return System.currentTimeMillis();
	}
	private PMF(){}
	/**
	 * Retorna o banco de dados configurado em src/META-INF/jdoconfig.xml
	 * @param database Interface database {@link Database}
	 * @return PersistenceManager
	 */
	public static PersistenceManager getPersistence(Database database) {
		return PMF.getPersistence(database.getDatabase());
	}
	/**
	 * @see #getPersistence(Database)
	 * @return PersistenceManager
	 * @param database {@link Database}
	 */
	public static PersistenceManager getPersistence(String database) {
		return JDOHelper.getPersistenceManagerFactory(database).getPersistenceManager();
	}
}

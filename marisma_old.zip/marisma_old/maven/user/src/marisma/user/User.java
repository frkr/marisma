package marisma.user;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;
import javax.jdo.annotations.Unique;

import marisma.Database;

@PersistenceCapable
@Unique(name="LOGIN_IDX",members={"login"})
public class User implements Database {

	public String getDatabase() {
		return "Marisma";
	}

	@PrimaryKey
	@Persistent
	private Long id;
	@Persistent
	private String login="";
	@Persistent
	private String pass="";
	@Persistent
	private Integer cancreate=0;

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLogin() {
		return this.login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPass() {
		return this.pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Integer getCancreate() {
		return this.cancreate;
	}
	public void setCancreate(Integer cancreate) {
		this.cancreate = cancreate;
	}

}

package marisma.user;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import marisma.PMF;

/**
 * Implementa��o simples usando datanucleus para o controle de seguran�a
 * @author davimesquita@gmail.com
 */
public class UserImpl implements Serializable, marisma.User {

	static {
		UserImpl.createTables();
	}

	private String login = null;
	private Set<String> roles = new HashSet<String>();

	/**
	 * <pre>
	 * Precau��es
	 * N�o pode existir um grupo com o nome de um usu�rio
	 * Retornar uma instancia nova exemplo: Nova instancia de UserImpl
	 * </pre>
	 */
	public marisma.User newLogin(String login, String pass) {
		UserImpl ret = new UserImpl();
		User tx = new User();
		PersistenceManager pm = PMF.getPersistence(tx);

		// Pegar usuario
		Query q = pm.newQuery(tx.getClass(), "login+pass == :loginpass");
		//q.declareParameters("String loginpass");
		List results = (List) q.execute(login+pass);
		if (results==null || results.size()!=1) return null;
		tx = (User) results.iterator().next();
		ret.login=tx.getLogin();

		// Definir grupos
		Set<String> grupos = new HashSet<String>();
		grupos.add(tx.getLogin());
		UserGroup group = new UserGroup();
		q = pm.newQuery(group.getClass(),"login == :usergroup");
		results = (List) q.execute(tx.getLogin());
		if (results!=null && results.size()>0) {
			for(Object linha: results) {
				group = (UserGroup) linha;
				grupos.add(group.getGroup());
			}
		}

		// Definir acessos
		Thread.yield();
		UserRole role = new UserRole();
		q = pm.newQuery(role.getClass(),"1==1");
		results = (List) q.execute();
		if (results!=null && results.size()>0) {
			for (Object linha: results) {
				role = (UserRole) linha;
				if (grupos.contains(role.getGroup())) {
					ret.roles.add(role.getRole());
				}
			}
		}
		Thread.yield();

		return ret;
	}

	private static void createTables() {
		User user = new User();
		UserGroup group = new UserGroup();
		UserRole marisma = new UserRole();

		PersistenceManager pm = PMF.getPersistence(user);
		user.setId(1L);
		user.setLogin("admin");
		user.setPass("admin");
		user.setCancreate(1);

		group.setId(1L);
		group.setGroup("Dono");
		group.setLogin(user.getLogin());

		marisma.setId(1L);
		marisma.setGroup("Dono");
		marisma.setRole("Marisma");

		try {
			pm.makePersistent(user);
			pm.makePersistent(group);
			pm.makePersistent(marisma);
			pm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void autoAddPermission(String fullstringaccess) {
		if (this.login!=null) {
			new Thread(){
				private String user;
				private String tgt;
				public void go(String user, String tgt) {
					this.user=user;
					this.tgt=tgt;
					this.setDaemon(true);
					this.setName("autoAddPermission-"+this.getId());
					this.start();
				}
				@Override
				public void run() {
					UserRole role = new UserRole();
					PersistenceManager pm = PMF.getPersistence(role);
					try {
						role.setRole(this.tgt);
						role.setGroup(this.user);
						pm.makePersistent(role);
						pm.close();
					} catch (Exception e) {
					}
				}
			}.go(this.login,fullstringaccess);
		}
	}

	public boolean checkAccess(String command, String role) {
		String fullstringaccess = command + "::" + role;
		if (this.roles.contains(fullstringaccess))
			return true;
		else if ( this.roles.contains(command) ) {
			this.roles.add(fullstringaccess);
			this.autoAddPermission(fullstringaccess);
			return true;
		}
		return false;
	}

}

package controller;

import java.io.IOException;

import javax.jdo.PersistenceManager;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.PMF;
import marisma.Wrapper;
import marisma.XMLData;
import marisma.output.OutputXSLT;
import marisma.user.UserRole;

/**
 * Sample
 */
public class ServletTest extends HttpServlet implements Servlet {
	static {
		System.setProperty("marisma.Wrapper.userimpl","marisma.user.UserImpl");
	}
	public String PAGE_HOME = "view/servletTest.xsl";
	public String ROLE_LOGIN = "login";
	public String ROLE_TESTE = "teste";

	static {
		try {
			UserRole role = new UserRole();
			role.setId(2L);
			role.setGroup("Dono");
			role.setRole("ServletTest::teste");
			PersistenceManager pm = PMF.getPersistence(role);
			pm.makePersistent(role);
			pm.close();
		} catch (Exception e) {
		}
	}

	public ServletTest() {
		super();
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.print(this.getClass().getName()+": getContentType: ");
		System.out.println(req.getContentType());
		XMLData data = new XMLData();
		Wrapper wrapper = new Wrapper(req,resp,this,new OutputXSLT(data,this.PAGE_HOME));

		String msg="nada";

		if (wrapper.getRole().equals("")) {
			msg="Entrada";
		} else if (wrapper.getRole().equals(this.ROLE_LOGIN)) {
			msg = "nao logou";

			if (wrapper.userLogin(wrapper.getParameter("login"),wrapper.getParameter("pass"))) {
				msg="logou";
			}

			if (wrapper.getParameterValues("teste") !=null && req.getParameterValues("teste").length>0) {
				msg+= " = ";
				for (String linha: wrapper.getParameterValues("teste")) {
					msg+=linha+", ";
				}
			}

			model.ServletTest test = new model.ServletTest();
			test = (model.ServletTest) wrapper.populate(test);
			System.out.println(test.getData());

		} else if (wrapper.getRole().equals(this.ROLE_TESTE)) {
			if (wrapper.checkAccess()) {
				msg = "Acesso permitido";
			} else {
				msg = "Acesso negado";
			}
		}

		data.addClosedTag("msg", msg);

		if (!wrapper.isUsed()) {
			wrapper.out();
		}
	}

}

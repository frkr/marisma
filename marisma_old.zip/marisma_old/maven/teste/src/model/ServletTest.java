package model;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import marisma.Database;
import marisma.Populate;

/**
 * Sample
 */
@PersistenceCapable
public class ServletTest implements Database, Populate {

	public String getDatabase() {
		return "Marisma";
	}

	@PrimaryKey
	@Persistent
	private Long id;
	@Persistent
	private String nome="";
	@Persistent
	private Date data=new Date();

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getData() {
		return this.data;
	}
	public void setData(Date data) {
		this.data = data;
	}

	public Object populate(Field field, String value) {
		if (field.getType().equals(Date.class)) {
			try {
				return new SimpleDateFormat("dd/MM/yyyy").parse(value);
			} catch (Exception e) {
			}
		}
		return null;
	}

}
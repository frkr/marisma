package marisma;

import javax.servlet.ServletException;

public class ForbiddenException extends ServletException {
	public ForbiddenException(String msg) {
		super(msg);
	}
}

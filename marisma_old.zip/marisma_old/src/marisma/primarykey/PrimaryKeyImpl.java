package marisma.primarykey;

import marisma.PrimaryKey;

public class PrimaryKeyImpl implements PrimaryKey {

	@Override
	public Long getNextId() {
		return System.currentTimeMillis();
	}

}

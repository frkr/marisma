package marisma;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class BizRoleAbstract extends HttpServlet implements Servlet {

	public BizRoleAbstract() {
		super();
	}

	private String getCommand() {
		return this.getServletConfig().getServletName();
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.process(this.getCommand(),req, resp,this);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.process(this.getCommand(),req, resp,this);
	}

	private static BizRoleMethod method = null;

	static {
		if (Wrapper.isGae()) {
			BizRoleAbstract.method = new BizRoleMethodImplGae();
		} else {
			BizRoleAbstract.method = new BizRoleMethodImpl();
		}
	}

	protected Method getMethod(String method) throws NoSuchMethodException {
		return BizRoleAbstract.method.getMethod(this.getClass(),method);
	}

	public void process(String command, HttpServletRequest req, HttpServletResponse resp, Servlet serv) throws ServletException, IOException {
		Wrapper w = new Wrapper(command,req,resp,serv);
		Object output = null;

		if (w.getRole().equals("")) {
			w.setRole("default");
		}

		try {
			Method m = this.getMethod( w.getRole() + "Role" );
			if (m.isAnnotationPresent(Secure.class)) {
				Secure sec = m.getAnnotation(Secure.class);
				boolean can=false;
				if (sec.byRole()) {
					can=w.checkAccess();
				} else {
					can=w.checkLogin();
				}
				if (!can)
					throw new ForbiddenException("Forbidden");
			}
			output = m.invoke(this, w);
			if (output!=null && !w.isUsed()) {
				this.out(w, m,(Output) output);
			}
		} catch (ForbiddenException f) {
			resp.sendError(HttpServletResponse.SC_FORBIDDEN);
		} catch (NoSuchMethodException e) {
			throw new ServletException(command + "." + w.getRole() + "Role()");
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(command + "." + w.getRole() + "Role(): " + e.getMessage());
		}
	}

	protected void out(Wrapper w, Method m, Output o) throws ServletException, IOException {
		w.out(o);
	}

	/**
	 * <pre>
	 * URL
	 * ?role=default
	 * </pre>
	 */
	public abstract Output defaultRole(Wrapper w) throws ServletException, IOException;

}

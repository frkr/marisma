package marisma;

public interface PrimaryKey {
	public Long getNextId();
}

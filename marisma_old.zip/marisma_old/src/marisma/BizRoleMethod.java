package marisma;

import java.lang.reflect.Method;

interface BizRoleMethod {
	public Method getMethod(Class<?> clazz, String method) throws NoSuchMethodException;
}

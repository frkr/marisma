package marisma;

import java.io.IOException;
import java.lang.reflect.Field;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Sample
 */
public class Filter implements javax.servlet.Filter {

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,FilterChain filter) throws IOException, ServletException {
		try {
			/*
			 * D� pra pegar IP, parametros e uma caralhada de coisas.
			 */

			Field f1 = filter.getClass().getDeclaredField("servlet");
			f1.setAccessible(true);
			Servlet s = (Servlet) f1.get(filter);
			System.out.println("servlet: " + s.getClass().getName());
			HttpServletRequest r = (HttpServletRequest) req;
			System.out.println("uri:     " + r.getRequestURI());
		} catch (Exception e) {
		}
		// Antes de executar o servlet
		filter.doFilter(req, resp);
		// Depois de executar o servlet \o/ haha
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

}

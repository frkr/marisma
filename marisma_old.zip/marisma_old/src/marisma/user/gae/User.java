package marisma.user.gae;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;
import javax.jdo.annotations.Unique;

import marisma.Database;

@PersistenceCapable(identityType = IdentityType.APPLICATION)
public class User implements Database {

	public String getDatabase() {
		return "transactions-optional";
	}

	@PrimaryKey
	@Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
	private Long id=null;
	@Persistent
	@Unique
	private String login="";
	@Persistent
	private String pass="";
	@Persistent
	private Integer cancreate=0;
	@Persistent
	private String redirect="";

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLogin() {
		return this.login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPass() {
		return this.pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Integer getCancreate() {
		return this.cancreate;
	}
	public void setCancreate(Integer cancreate) {
		this.cancreate = cancreate;
	}
	public String getRedirect() {
		return this.redirect;
	}
	public void setRedirect(String redirect) {
		this.redirect = redirect;
	}

}

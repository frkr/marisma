package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

import org.json.JSONException;
import org.json.JSONObject;

public class OutputJSON implements Output {

	private JSONObject json;
	private int ident=1;

	public JSONObject getJSON() {
		return this.json;
	}
	public void setJSON(JSONObject json) {
		this.json = json;
	}
	public int getIdent() {
		return this.ident;
	}
	public void setIdent(int ident) {
		this.ident = ident;
	}

	public OutputJSON(JSONObject json) {
		this.json=json;
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		try {
			wrapper.getResponse().getWriter().print(this.json.toString(this.ident));
		} catch (JSONException e) {
			throw new ServletException(e.getMessage());
		}
	}

}

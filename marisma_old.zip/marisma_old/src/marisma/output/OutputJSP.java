package marisma.output;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

public class OutputJSP implements Output {

	private String jsp;
	private Map<String,Object> vo = new HashMap<String,Object>();

	public String getJSP() {
		return this.jsp;
	}
	public void setJSP(String jsp) {
		this.jsp = jsp;
	}
	public void setVO(Map<String, Object> vo) {
		this.vo = vo;
	}
	public Map<String, Object> getVO() {
		return this.vo;
	}

	public OutputJSP(String jsp) {
		this.jsp=jsp;
	}
	public OutputJSP(String jsp, Object vo) {
		this(jsp);
		this.setVO(vo);
	}

	public void out(Wrapper wrapper) throws ServletException, IOException {
		for (String linha: this.vo.keySet()) {
			wrapper.getRequest().setAttribute(linha, this.vo.get(linha));
		}
		wrapper.getRequest().getRequestDispatcher(this.jsp).forward(wrapper.getRequest(), wrapper.getResponse());
	}

	public void setVO(String name, Object obj) {
		this.vo.put(name, obj);
	}

	public void setVO(Object object) {
		this.setVO(object.getClass().getSimpleName(),object);
	}

}

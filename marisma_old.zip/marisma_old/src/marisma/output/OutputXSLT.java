package marisma.output;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;
import marisma.XMLData;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.transform.XSLTransformException;
import org.jdom.transform.XSLTransformer;

public class OutputXSLT implements Output, marisma.framework.Output {

	private static String projectpath="";

	static {
		//==== Usando GAE (Google AppEngine) deve-se usar o SAXON
		/*
		 * O uso de Saxon � opcional. Porem existem alguns softwares de XLST que n�o s�o compativeis com a implementa��o nativa do java.
		 * 
		 * Talvez em alguns XSL para o Dreamweaver CS3 tenha que usar o Saxon e + esta linha (( colocar logo apos: <xsl:stylesheet...> ))
		 * <xsl:output method="html" encoding="utf-8" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
		 */
		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");

		// TODO Usar system propeties
		InputStream in = OutputXSLT.class.getResourceAsStream("OutputXSLT.properties");
		try {
			Properties prop = new Properties();
			prop.load(in);
			String t = prop.getProperty("projectpath");
			OutputXSLT.projectpath = (t==null) ? "" : t;
		} catch (Exception e) {
		}
		try {
			in.close();
		} catch (Exception e) {
		}
	}

	private String xslt;
	private XMLData xmld;
	private Format format = Format.getCompactFormat();

	public OutputXSLT(){}

	public String getXSLT() {
		return this.xslt;
	}
	public void setXSLT(String xslt) {
		this.xslt = xslt;
	}
	public XMLData getXML() {
		return this.xmld;
	}
	public void setXML(XMLData xml) {
		this.xmld=xml;
	}
	public Format getFormat() {
		return this.format;
	}
	public void setFormat(Format format) {
		this.format = format;
	}

	public OutputXSLT(XMLData data, String xsl) {
		this.xslt=xsl;
		this.xmld=data;
	}

	public static XMLData transform(XSLTransformer file, Document xml) throws XSLTransformException {
		return new XMLData(file.transform(xml));
	}

	public void out(Wrapper wrapper) throws ServletException, IOException {
		try {
			File file = wrapper.makeFile(this.xslt);
			if (!file.exists()) throw new ServletException("XSL not found - " + this.xslt);

			wrapper.getResponse().setContentType("text/html");
			wrapper.getResponse().getWriter().print(
					OutputXSLT.transform(new XSLTransformer(file), this.xmld.getDocument()).getXML(this.format)
			);

			if (!OutputXSLT.projectpath.equals("")) {
				this.saveXML();
			}
		} catch (XSLTransformException e) {
			throw new ServletException(e.getMessage() + " " + e.getCause());
		}
	}

	private void saveXML() {
		new Thread() {
			public void go() {
				this.setName("OutputXSLT.saveXML-" + this.getId());
				this.setDaemon(true);
				this.start();
			}
			@Override
			public void run() {
				try {
					File file = new File(OutputXSLT.projectpath + OutputXSLT.this.xslt.replaceFirst(".xsl", ".xml"));
					FileWriter wt = new FileWriter(file);
					wt.write(OutputXSLT.this.xmld.getXML());
					wt.close();
					System.out.println(file);
				} catch (Exception e) {
					System.err.println("OutputXSLT.saveXML:OutputXSLT.properties");
					e.printStackTrace();
				}
			}
		}.go();
	}
	public void setResource(String resource) {
		this.setXSLT(resource);
	}

}

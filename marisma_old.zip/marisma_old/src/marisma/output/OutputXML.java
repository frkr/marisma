package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;
import marisma.XMLData;

import org.jdom.Document;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class OutputXML implements Output {

	private XMLData xml;
	private Format format = Format.getCompactFormat();

	public Format getFormat() {
		return this.format;
	}
	public void setFormat(Format format) {
		this.format = format;
	}
	public XMLData getXML() {
		return this.xml;
	}
	public void setXML(XMLData xml) {
		this.xml = xml;
	}
	public OutputXML(XMLData xml) {
		this.xml=xml;
	}
	public OutputXML(Document xml) {
		this(new XMLData(xml));
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		wrapper.getResponse().getWriter().print(new XMLOutputter(this.format).outputString(this.xml.getDocument()));
	}

}

package marisma.output;

import java.io.IOException;

import javax.servlet.ServletException;

import marisma.Output;
import marisma.Wrapper;

public class OutputStringBuffer implements Output {

	private StringBuffer stringBuffer;

	public StringBuffer getStringBuffer() {
		return this.stringBuffer;
	}
	public void setStringBuffer(StringBuffer out) {
		this.stringBuffer = out;
	}

	public OutputStringBuffer(StringBuffer out) {
		this.stringBuffer=out;
	}
	public OutputStringBuffer(String out) {
		this(new StringBuffer(out));
	}

	@Override
	public void out(Wrapper wrapper) throws ServletException, IOException {
		wrapper.getResponse().getWriter().print(this.stringBuffer);
	}

}

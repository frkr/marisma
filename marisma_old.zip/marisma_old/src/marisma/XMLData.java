package marisma;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jdom.CDATA;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Text;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class XMLData implements Serializable {
	private Document xml;
	private Element root;
	private List<Element> group = new ArrayList<Element>();
	private Element tag=null;

	public XMLData() {
		this("document");
	}

	public XMLData(String root) {
		this(new Element(root));
	}

	public XMLData(Element root) {
		this.xml = new Document();
		this.root = root;
		this.xml.addContent(this.root);
	}

	public XMLData(Document doc) {
		this.setDocument(doc);
	}

	public void setDocument(Document doc) {
		this.xml=doc;
		if (this.xml.hasRootElement()) {
			this.root=this.xml.getRootElement();
		} else {
			this.root=new Element("document");
			this.xml.addContent(this.root);
		}
	}

	public Document getDocument() {
		return this.xml;
	}

	public String getXML() {
		return this.getXML(Format.getPrettyFormat());
	}

	public String getXML(Format format) {
		XMLOutputter xml = new XMLOutputter(format);
		return xml.outputString(this.xml);
	}

	public void addClosedTag(String name, String value, boolean cdata) {
		Element ele = new Element(name);
		ele.addContent(cdata ? new CDATA(value) : new Text(value));
		this.addGroupElement(ele);
	}

	public void addClosedTag(String name, String value) {
		this.addClosedTag(name, value, false);
	}

	public void addParameterTag(String name) {
		this.tag=new Element(name);
		this.addGroupElement(this.tag);
	}

	public void addParameter(String name, String value) {
		if (this.tag==null) {
			this.addParameterTag("record");
		}
		this.tag.setAttribute(name, value);
	}

	public void openGroup(String name) {
		Element ele = new Element(name);
		this.addGroupElement(ele);
		this.group.add(ele);
	}

	public void closeGroup() {
		if (this.group.size()>0) {
			this.group.remove(this.group.size()-1);
		}
	}

	private void addGroupElement(Element ele) {
		if (this.group.size()==0) {
			this.root.addContent(ele);
		} else {
			this.group.get(this.group.size()-1).addContent(ele);
		}
	}

}
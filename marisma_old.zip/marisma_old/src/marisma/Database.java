package marisma;

public interface Database {
	public String getDatabase();
}

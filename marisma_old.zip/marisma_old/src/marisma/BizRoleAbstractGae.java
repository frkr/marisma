package marisma;

import java.lang.reflect.Method;

public abstract class BizRoleAbstractGae extends BizRoleAbstract {

	public BizRoleAbstractGae() {
		super();
	}

	@Override
	protected Method getMethod(String method) throws NoSuchMethodException {
		Method[] mts = this.getClass().getDeclaredMethods();
		for (Method linha: mts) {
			if (linha.getName().equals(method))
				return linha;
		}
		throw new NoSuchMethodException(method);
	}

}

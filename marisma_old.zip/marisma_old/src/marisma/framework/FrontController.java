package marisma.framework;

import java.io.IOException;
import java.lang.reflect.Field;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.ForbiddenException;

public class FrontController implements javax.servlet.Filter {

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,FilterChain filter) throws IOException, ServletException {
		HttpServletRequest r = (HttpServletRequest) req;
		HttpServletResponse p = (HttpServletResponse) resp;
		if (r.getRequestURI().endsWith(".do")) {
			try {
				Field f1 = filter.getClass().getDeclaredField("servlet");
				f1.setAccessible(true);
				Servlet s = (Servlet) f1.get(filter);

				String uri = r.getRequestURI().substring(r.getRequestURI().indexOf("/", 1)+1,r.getRequestURI().indexOf(".do"));
				Marisma.framework(uri, r, p, s);
			} catch (MarismaException e) {
				e.printStackTrace();
				throw new ServletException(e.getMessage());
			} catch (ForbiddenException e) {
				p.sendError(HttpServletResponse.SC_FORBIDDEN);
			} catch (Exception e) {
				throw new ServletException(r.getRequestURI() + ":" + e.getMessage());
			}
		} else {
			// Se n�o existir no Framework. Delegar para o Tomcat:
			filter.doFilter(req, resp);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

}

package marisma.framework;


public class MarismaException extends Exception {
	public MarismaException(String msg) {
		super(msg);
	}
}

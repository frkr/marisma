package marisma.framework;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.ForbiddenException;
import marisma.Wrapper;
import marisma.XMLData;

public class Marisma {

	static {
		try {
			MarismaCommand c = new MarismaCommand();
			c.setId(1L);
			c.setCommand("Marisma");

			MarismaRole rdefault = new MarismaRole();
			rdefault.setId(1L);
			rdefault.setCommand(1L);
			rdefault.setAccess(0);
			rdefault.setRole("default");
			rdefault.setOutput("marisma.output.OutputXSLT");
			rdefault.setResource("view/marisma/marisma.xsl");
			rdefault.setSql(new StringBuffer("SELECT * FROM USER"));

			PersistenceManager pm = Wrapper.getPersistence(c);
			try {
				pm.makePersistent(c); // FIXME Isso tah muito feio
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				pm.makePersistent(rdefault); // FIXME Isso tah muito feio
			} catch (Exception e) {
				e.printStackTrace();
			}
			pm.close();
		} catch (Exception e) {
		}
	}

	public static void framework(String command, HttpServletRequest req, HttpServletResponse resp, Servlet serv) throws MarismaException, ForbiddenException  {
		Wrapper w = new Wrapper(command, req, resp, serv);

		if (w.getRole().equals("")) {
			w.setRole("default");
		}

		if (command.equals("Marisma") && w.getRole().equals("login")) {
			try {
				w.getResponse().getWriter().write(Boolean.toString( w.userLogin(w.getParameter("username"), w.getParameter("password")) ));
			} catch (Exception e) {
			}
			return;
		}

		MarismaCommand c = new MarismaCommand();
		PersistenceManager pm = Wrapper.getPersistence(c);

		Query q = pm.newQuery(c.getClass(), "command == :cm");
		List results = (List) q.execute(command);
		if (results==null || results.size()!=1) throw new MarismaException("not found - Marisma:" + command);
		c = (MarismaCommand) results.iterator().next();

		MarismaRole r = new MarismaRole();
		Query q2 = pm.newQuery(r.getClass(), "command == :cm && role == :ro");
		List results2 = (List) q2.execute(c.getId(),w.getRole());
		if (results2==null || results2.size()!=1) throw new MarismaException("not found - Marisma:" + command + "." + w.getRole());
		r = (MarismaRole) results2.iterator().next();

		boolean can=true;
		if (r.getAccess().equals(1)) {
			can=w.checkLogin();
		} else if (r.getAccess().equals(2)) {
			can=w.checkAccess();
		}
		if (!can)
			throw new ForbiddenException("Forbidden " + command + "." + w.getRole());

		// TODO Regra de negocio SQL
		XMLData data = new XMLData();

		int sqls=1;
		try {
			// FIXME Usar datanucleus
			Connection conn = (Connection) pm.getDataStoreConnection().getNativeConnection();
			Statement st = conn.createStatement();
			st.execute(r.getSql().toString());
			ResultSet rs = st.getResultSet();
			ResultSetMetaData mt = rs.getMetaData();

			data.openGroup("sql" + sqls++);
			String table="";
			while (rs.next()) {
				if (!mt.getCatalogName(1).equals(table)) {
					table=mt.getCatalogName(1);
					if (!mt.getCatalogName(1).equals("")) {
						data.closeGroup();
					}
					data.openGroup(mt.getCatalogName(1));
				}
				data.openGroup("record");
				for (int i=1;i<=mt.getColumnCount();i++) {
					data.addClosedTag(mt.getColumnName(i), rs.getString(i), true);
				}
				data.closeGroup();
			}
			data.closeGroup();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new MarismaException("SQL Error: " + command + "." + w.getRole() + " | " + e.getMessage());
		}
		//			Query q3 = pm.newQuery(SQLQuery.class,r.getSql());
		//			List rt = (List) q3.execute();
		//			Object[] linha = (Object[]) rt.iterator().next();
		//			System.out.println(linha[0]);

		//////////////////////////////

		Output o = null;
		try {
			o = (Output) Marisma.class.getClassLoader().loadClass(r.getOutput()).newInstance();
		} catch (Exception e) {
			throw new MarismaException("Resource error: " + command + "." + w.getRole());
		}
		o.setXML(data);
		o.setResource(r.getResource());
		try {
			w.out(o);
		} catch (Exception e) {
			e.printStackTrace();
			throw new MarismaException("ResourceOutput error: " + command + "." + w.getRole());
		}
	}

}

package marisma.framework;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;
import javax.jdo.annotations.Unique;

import marisma.Database;

@PersistenceCapable
public class MarismaCommand implements Database {

	public String getDatabase() {
		return "Marisma";
	}

	@PrimaryKey
	@Persistent
	private Long id=null;
	@Persistent
	@Unique
	private String command=null;

	public Long getId() {
		return this.id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCommand() {
		return this.command;
	}
	public void setCommand(String command) {
		this.command = command;
	}

}

package marisma;

import java.lang.reflect.Field;

public interface Populate {
	public Object populate(Field field, String value);
}

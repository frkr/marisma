package marisma;

import java.io.IOException;

import javax.servlet.ServletException;

public interface Output {
	public void out(Wrapper wrapper) throws ServletException, IOException;
}

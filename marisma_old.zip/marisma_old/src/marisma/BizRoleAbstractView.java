package marisma;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;

import marisma.output.OutputJSON;
import marisma.output.OutputXML;
import marisma.output.OutputXSLT;

import org.jdom.JDOMException;
import org.json.JSONObject;

public abstract class BizRoleAbstractView extends BizRoleAbstract {

	@Override
	protected void out(Wrapper w, Method m, Output o) throws ServletException, IOException {
		OutputXML xml=null;
		try {
			xml = (OutputXML) o;
		} catch (Exception e) {
			throw new ServletException( this.getClass().getName() + " - OutputXML");
		}

		if (w.getParameter("output") !=null) {
			if (w.getParameter("output").equals("json")) { // TODO Testar
				w.out(new OutputJSON(new JSONObject(xml.getXML().getDocument())));
			} else if (w.getParameter("output").equals("xml")) {
				w.out(o);
			} else if (w.getParameter("output").equals("xslt") && m.isAnnotationPresent(View.class)) {
				View v = m.getAnnotation(View.class);
				try {
					w.out(new OutputXML(w.openXML(w.makeFile(v.name()))));
				} catch (JDOMException e) {
					throw new ServletException( this.getClass().getName() + "." + v.name());
				}
			}
		}
		if(!w.isUsed() && m.isAnnotationPresent(View.class)) {
			View v = m.getAnnotation(View.class);
			w.out(new OutputXSLT(xml.getXML(), v.name()));
		} else {
			super.out(w, m, o);
		}
	}

}

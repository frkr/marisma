package marisma;


public interface User {

	/**
	 * <pre>
	 * Precau��es
	 * N�o pode existir um grupo com o nome de um usu�rio
	 * Retornar uma instancia nova exemplo: Nova instancia de UserImpl
	 * </pre>
	 */
	public User newLogin(String login, String pass);
	public boolean checkAccess(String command, String role);

}

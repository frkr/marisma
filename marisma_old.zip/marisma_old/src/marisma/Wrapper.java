package marisma;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.logging.Logger;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.annotations.Persistent;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import marisma.primarykey.PrimaryKeyImpl;
import marisma.user.UserImpl;
import marisma.user.gae.UserImplGae;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

public class Wrapper {

	private static Logger log = Logger.getLogger(Wrapper.class.getName());
	private static User userimpl = null;
	private static PrimaryKey primarykeyimpl = null;
	private static boolean isgae = false;


	static {
		try {
			Wrapper.class.getClassLoader().loadClass("org.datanucleus.store.appengine.jdo.DatastoreJDOPersistenceManagerFactory");
			Wrapper.isgae=true;
		} catch (Exception e) {
		}
		InputStream in = Wrapper.class.getResourceAsStream("Wrapper.properties");
		try {
			Properties prop = new Properties();
			prop.load(in);
			String t = prop.getProperty("UserImpl");
			try {
				Wrapper.userimpl = (User) Wrapper.class.getClassLoader().loadClass(t).newInstance();
			} catch (Exception e) {
			}
			t = prop.getProperty("PrimaryKeyImpl");
			try {
				Wrapper.primarykeyimpl = (PrimaryKey) Wrapper.class.getClassLoader().loadClass(t).newInstance();
			} catch (Exception e) {

			}
		} catch (Exception e) {
		}
		try {
			in.close();
		} catch (Exception e) {
		}
		if (Wrapper.userimpl==null) {
			if (Wrapper.isGae()) {
				Wrapper.userimpl = new UserImplGae();
			} else {
				Wrapper.userimpl = new UserImpl();
			}
		}
		if (Wrapper.primarykeyimpl==null) {
			Wrapper.primarykeyimpl = new PrimaryKeyImpl();
		}
	}

	public static boolean isGae() {
		return Wrapper.isgae;
	}

	private User user=null;
	private HttpServletRequest req;
	private HttpServletResponse resp;
	private Servlet serv;
	private Boolean used=false;
	private String role;
	private Output output=null;
	private String command;

	/**
	 * Retorna se o SERVLET foi usado
	 */
	public boolean isUsed() {
		return this.used;
	}
	/**
	 * Configura se o SERVLET foi usado
	 */
	public void setUsed(boolean used) {
		this.used=used;
	}

	public Output getOutput() {
		return this.output;
	}
	public void setOutput(Output output) {
		this.output = output;
	}

	public HttpServletRequest getRequest() {
		return this.req;
	}
	public HttpServletResponse getResponse() {
		return this.resp;
	}
	public Servlet getServlet() {
		return this.serv;
	}

	/**
	 * Retorna a proxima primarykey. Se a implementa��o estiver vazia: Retorna null
	 */
	public static synchronized Long getNextId() {
		//if (Wrapper.primarykeyimpl==null) return null;
		return Wrapper.primarykeyimpl.getNextId();
	}

	public Wrapper(HttpServletRequest req, HttpServletResponse resp, Servlet serv) {
		this(serv.getServletConfig().getServletName(),req,resp,serv,null);
	}

	public Wrapper(HttpServletRequest req, HttpServletResponse resp, Servlet serv, Output output) {
		this(serv.getServletConfig().getServletName(),req,resp,serv,output);
	}

	public Wrapper(String command, HttpServletRequest req, HttpServletResponse resp, Servlet serv) {
		this(command,req,resp,serv,null);
	}

	public Wrapper(String command, HttpServletRequest req, HttpServletResponse resp, Servlet serv, Output output) {
		this.command=command;
		this.req=req;
		this.resp=resp;
		this.serv=serv;
		this.output=output;
		String tgt = req.getParameter("role");
		if (tgt==null) {
			tgt="";
		}
		this.role=tgt;
		try {
			this.user = (User) req.getSession(false).getAttribute("marisma::user");
		} catch (Exception e) {
		}
		if (this.user==null
				&& req.getParameter("login") != null
				&& !req.getParameter("login").equals("")
				&& req.getParameter("pass") != null
				&& !req.getParameter("pass").equals("")
		) {
			this.userLogin(req.getParameter("login"), req.getParameter("pass"));
		}
	}

	public void setRole(String r) {
		this.role=r;
	}

	/**
	 * Retorna o usu�rio logado ou null
	 */
	public User getUser() {
		return this.user;
	}

	/**
	 * Retorna o alvo atual ou ""
	 */
	public String getRole() {
		return this.role;
	}

	/**
	 * Utilitario para encontrar arquivos desde a raiz do projeto
	 */
	public File makeFile(String file) {
		File arq = new File(this.serv.getServletConfig().getServletContext().getRealPath(file));
		return arq;
	}

	public void out(Output output) throws ServletException, IOException {
		this.output=output;
		this.out();
	}

	public void out() throws ServletException, IOException {
		if (this.used) throw new ServletException("Servlet - Wrapper isUsed");
		if (this.output==null) throw new ServletException("Output Interface - not set");
		this.output.out(this);
		this.used=true;
	}

	public Document openXML(File xml) throws JDOMException, IOException {
		return new SAXBuilder().build(xml);
	}

	public static PersistenceManager getPersistence(Database database) {
		return Wrapper.getPersistence(database.getDatabase());
	}
	public static PersistenceManager getPersistence(String database) {
		return JDOHelper.getPersistenceManagerFactory(database).getPersistenceManager();
	}

	public boolean userLogin(String login, String pass) {
		if (Wrapper.userimpl==null) return false;
		User logado = Wrapper.userimpl.newLogin(login, pass);
		if (logado==null) return false;
		this.user=logado;
		this.req.getSession(true).setAttribute("marisma::user", this.user);
		return true;
	}

	public void userLogout() {
		this.user=null;
		this.req.getSession(false).setAttribute("marisma::user", null);
	}

	/**
	 * @see request.getParameter(arg0);
	 */
	public String getParameter(String arg) {
		return this.req.getParameter(arg);
	}

	/**
	 * @see request.getParameterValues(arg0);
	 */
	public String[] getParameterValues(String arg) {
		return this.req.getParameterValues(arg);
	}

	/**
	 * Verifica se o usuario tem permissao para uma acao
	 * 
	 */
	public boolean checkAccess() {
		if (this.user==null) return false;
		return this.user.checkAccess(this.command,this.role);
	}

	/**
	 * Verifica se o usuario tem permissao para uma acao
	 * 
	 */
	public boolean checkAccess(String command, String role) {
		if (this.user==null) return false;
		return this.user.checkAccess(command,role);
	}

	/**
	 * Verifica se o usuario esta logado
	 */
	public boolean checkLogin() {
		if (this.user!=null)
			return true;
		return false;
	}

	/**
	 * @see populate(Class)
	 */
	public Object populate(Object jdo) throws ServletException {
		return this.populate(jdo.getClass());
	}

	/**
	 * Pega os valores no formulario que tenham a interface 'Persistent'
	 */
	public Object populate(Class<? extends Object> jdo) throws ServletException {
		Object ret=null;
		try {
			ret = jdo.newInstance();
			for (Field field: jdo.getDeclaredFields()) {
				if (field.isAnnotationPresent(Persistent.class) && this.req.getParameter(field.getName()) != null) {
					Object obj = this.req.getParameter(field.getName());

					// Detecta e valida os campos
					if (field.getType().equals(Long.class)) {
						obj = Long.parseLong(obj.toString());
					} else if (field.getType().equals(Double.class)) {
						obj = Double.parseDouble(obj.toString());
					} else if (field.getType().equals(Integer.class)) {
						obj = Integer.parseInt(obj.toString());
					} else if (field.getType().equals(String.class)) {
						obj = obj.toString();
					} else {
						try {
							Method m = ret.getClass().getDeclaredMethod("populate", Field.class, String.class);
							obj = m.invoke(ret,field, obj.toString());
						} catch (Exception e) {
						}
					}

					try {
						field.setAccessible(true);
						field.set(ret, obj);
					} catch (Exception e) {
						Wrapper.log.warning("not populated - " +jdo.getName() + "." + field.getName());
					}
				}
			}
		} catch (Exception ee) {
			throw new ServletException("populate - " + jdo.getName());
		}
		return ret;
	}

}
